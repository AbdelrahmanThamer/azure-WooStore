# Change Log

## [ v4.3.0 ] - 18th October 2022 - Aniket Malik
* Added support for Digits Phone Login / Signup Plugin
* [REQUIRED] WooStore Pro App version 3.3.0

## [ v4.2.0 ] - 12th October 2022 - Aniket Malik
* Integrated product-add-ons plugin
* Removed Cocart plugin
* Added WooStore Pro Cart endpoints
* [REQUIRED] WooStore Pro App version 3.2.0

## [ v4.1.1 ] - 9th October 2022 - Aniket Malik
* Updated social login account creation to check for errors

## [ v4.1.0 ] - 28th August 2022 - Aniket Malik
* Added endpoint to allow login and redirect to a new url

## [ v4.0.0 ] - 20th August 2022 - Aniket Malik
* Integrated app builder related functions
* Added functionality to Delete User Account
* [REQUIRED] WooStore Pro Application version 3.0.0 or higher

## [ v3.2.3 ] - 31st January 2022 - Aniket Malik
* Enhanced cart in session creation.
* Fixed syntax errors for some strict php version

## [ v3.2.2 ] - 28 January 2022 - Aniket Malik
* Fixed syntax errors for some strict php version

## [ v3.2.1 ] - 23 January 2022 - Aniket Malik
* Fixed cart session to get shipping mehtods.

## [ v3.2.0 ] - 3rd December 2021 - Aniket Malik
* Added new endpoints for dynamic filter attributes based on selection
* [REQUIRED] WooStore Pro Applicaion version 2.2.0 or higher

## [ v3.1.1 ] - 21 November 2021 - Aniket Malik
* Fixed params not being read properly.

## [ v3.1.0 ] - 13 November 2021 - Aniket Malik
* Enhanced the native checkout feature

## [ v3.0.0 ] - 25th October 2021 - Aniket Malik
* Added support for Native Checkout.

## [ v2.2.0 ] - 10th September 2021 - Aniket Malik
* Added Support for Multi vendors. Supported plugins are: Dokan, WCFM, WCMp

## [ v2.1.1 ] - 30th July 2021 - Aniket Malik
* Using name spaces to avoid plugin clash

## [ v2.1.0 ] - 22nd July 2021 - Aniket Malik
* Added Product Attribute to support Variation Swatches for WooCommerce Plugin.
* Improved product search query to include multiple taxonomies ( Added custom filter to modify product query)

## [ v2.0.0 ] - 6th July 2021 - Aniket Malik
* Updated Framework for performance
* Removed dependency on CoCart Lite and CoCart Get Cart Enhanced plugins

## [ v1.4.0 ] - 25th June 2021 - Aniket Malik
* Added Cart functionality into WooStore Pro Api and removed Cocart and CoCart enhanced depedency.

## [ v1.3.3 ] - 13th April 2021 - Aniket Malik
* Fixed Apple login url not found issue

## [ v1.3.2 ] - 13th April 2021 - Aniket Malik
* Updated - Checkout url fetch method

## [ v1.3.1 ] - 13th April 2021 - Aniket Malik
* Updated - Admin UI

## [ v1.3.0 ] - 13th April 2021 - Aniket Malik
* Added - support for jwt auth token encode and decode natively.

## [ v1.2.0 ] - 9th April 2021 - Aniket Malik
* Added - Support to get points for product with a product id

## [ v1.1.1 ] - 8th April 2021 - Aniket Malik
* Added - Support to add reviews through an API endpoint

## [ v1.1.0 ] - 8th April 2021 - Aniket Malik
* Added - Support for WooCommerce Rewards and Points Plugin for WooStore Pro Mobilde application.