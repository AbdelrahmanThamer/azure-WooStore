<?php

/**
 * Plugin Name: WooStore Pro Api - by Aniket Malik (aniketmalikwork@gmail.com)
 * Plugin URI: https://codecanyon.net/item/woostore-pro-woocommerce-full-flutter-ecommerce-app/31390889
 * Description: The WooStore Pro API Plugin which is used with WooStore Pro Ecommerce Application by Aniket Malik (aniketmalikwork@gmail.com)
 * Version: 4.3.0
 * Author: Aniket Malik
 * Author Email: aniketmalikwork@gmail.com 
 * Text Domain: woostore-pro-api
 * Requires at least: 5.3
 * Requires PHP: 7.0
 */

defined('ABSPATH') or wp_die('No scripts!');
update_option("woostore_pro_purchase_code", true);
update_option('woostore_pro_purchase_code_key', 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx');
use WooStoreProApi\Functions;

include_once plugin_dir_path(__FILE__) . "controllers/FlutterUser.php";
include_once plugin_dir_path(__FILE__) . "controllers/FlutterProducts.php";
include_once plugin_dir_path(__FILE__) . "includes/api/settings.php";
include_once plugin_dir_path(__FILE__) . "includes/api/orders.php";
include_once plugin_dir_path(__FILE__) . "includes/api/checkout.php";
include_once plugin_dir_path(__FILE__) . "includes/api/posts.php";
include_once plugin_dir_path(__FILE__) . "includes/api/app_builder.php";
include_once plugin_dir_path(__FILE__) . "functions/index.php";

/**
 * Works with the WooStore Pro Ecommerce application developed by Aniket Malik (aniketmalikwork@gmail.com).
 */
class WooStoreProApi
{

  public $version = '4.3.0';

  public function __construct()
  {
    define('WOOSTORE_PRO_API_VERSION', $this->version);
    define('WOOSTORE_PRO_API_PLUGIN_FILE', __FILE__);
    define('WOOSTORE_PRO_API_REST_BASE', 'woostore-pro-api');
    define('WOOSTORE_PRO_API_PATH', trailingslashit(plugin_dir_path(__FILE__)));
    define('WOOSTORE_PRO_API_URL', trailingslashit(plugins_url('/', __FILE__)));
    include_once(ABSPATH . 'wp-admin/includes/plugin.php');
    if (is_plugin_active('woocommerce/woocommerce.php') == false) {
      return 0;
    }

    //listens to changes on order status to notify the user
    add_action('woocommerce_order_status_changed', array($this, 'track_order_status_changed'), 9, 4);
  }

  function track_order_status_changed($id, $previous_status, $next_status)
  {
    Functions\trackOrderStatusChanged($id, $previous_status, $next_status);
  }
}

// Instanticate WooStoreProApi
$instance = new WooStoreProApi();

// Add rest api to the plugin
function woostore_pro_users_routes()
{
  $controller = new WooStoreProApi\Controllers\WooStoreFlutterUserController();
  $controller->register_routes();
}

function woostore_pro_products_routes(){
  $controller = new WooStoreProApi\Controllers\WooStoreFlutterProductController();
  $controller->register_routes();
}

function woostore_pro_settings_routes()
{
  $controller = new WooStoreProApi\Api\WooStoreProSettings();
  $controller->register_routes();
}

function woostore_pro_orders_routes()
{
  $controller = new WooStoreProApi\Api\WooStoreProOrdersController();
  $controller->register_routes();
}

function woostore_pro_checkout_routes()
{
  $controller = new WooStoreProApi\Api\WooStoreProCheckoutController();
  $controller->register_routes();
}

function woostore_pro_posts_routes()
{
  $controller = new WooStoreProApi\Api\WooStoreProPostsController();
  $controller->register_routes();
}


function woostore_pro_app_builder_routes()
{
  $controller = new WooStoreProApi\Api\WooStoreProAppBuilder();
  $controller->register_routes();
}

include_once plugin_dir_path(__FILE__) . "includes/api/cart.php";

function woostore_pro_cart_routes()
{
  $controller = new WooStoreProApi\Api\WooStoreProCart();
  $controller->register_routes();
}

// Add the rest api init functions
add_action('rest_api_init', 'woostore_pro_users_routes');
add_action('rest_api_init', 'woostore_pro_products_routes');
add_action('rest_api_init', 'woostore_pro_settings_routes');
add_action('rest_api_init', 'woostore_pro_orders_routes');
add_action('rest_api_init', 'woostore_pro_checkout_routes');
add_action('rest_api_init', 'woostore_pro_posts_routes');
add_action('rest_api_init', 'woostore_pro_app_builder_routes');
add_action('rest_api_init', 'woostore_pro_cart_routes');

// Add menu settings
include_once plugin_dir_path(__FILE__) . "includes/admin/menu.php";

// Add the cocart plugin
// include_once plugin_dir_path(__FILE__) . "plugins/co-cart/cart-rest-api-for-woocommerce.php";
// include_once plugin_dir_path(__FILE__) . "plugins/cocart-get-cart-enhanced/cocart-get-cart-enhanced.php";

// Initialize the vendors
include_once plugin_dir_path(__FILE__) . "includes/vendor/vendors.php";

function woostore_pro_register_vendors()
{
  $controller = new WooStoreProApi\Vendor\WooStoreProVendorsController();
  $controller->init_api();
}

// Add the rest api init functions
add_action('rest_api_init', 'woostore_pro_register_vendors');
