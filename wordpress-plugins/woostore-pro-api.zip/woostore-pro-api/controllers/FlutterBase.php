<?php
namespace WooStoreProApi\Controllers;
class WooStoreFlutterBaseController
{
    /**
     * Check permissions for the posts.
     *
     * @param WP_REST_Request $request Current request.
     */
    public function sendError($code, $message, $statusCode, $data = array())
    {
        return new \WP_Error($code, $message, array('status' => $statusCode, "extra_data" => $data));
    }

    public function checkApiPermission()
    {
        $code = get_option('woostore_pro_purchase_code_key');
        if ($code !== null && $code !== false && strlen($code) >= 10) {
            return true;
        } else {
            return $this->sendError('invalid_license', 'The application has not been activated with a valid license, please contact the admin to activate the application', 403);
        }
    }
}
