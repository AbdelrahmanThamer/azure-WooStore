<?php

namespace WooStoreProApi\Controllers;

use WOOSTORE_PRO_API\JWT\JWT;
use WP_REST_Response;
use WP_REST_Request;
use WP_Error;

require_once(plugin_dir_path(__FILE__) . 'libraries/src/JWT.php');
require_once(__DIR__ . '/FlutterBase.php');
require_once(plugin_dir_path(__FILE__) . '../functions/index.php');

class WooStoreFlutterUserController extends WooStoreFlutterBaseController
{

  public function __construct()
  {
    $this->namespace = 'woostore_pro_api/flutter_user';
  }

  public function register_routes()
  {

    register_rest_route($this->namespace, '/get_user', array(
      array(
        'methods'   => \WP_REST_Server::CREATABLE,
        'callback'  => array($this, 'get_user'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/reset_password', array(
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'reset_password'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/authenticate', array(
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'authenticate'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/change_password', array(
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'change_password'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/change_password_v2', array(
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'change_password_v2'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/sign_up', array(
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'register'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/register', array(
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'register'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/generate_auth_cookie', array(
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'generate_auth_cookie'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/fb_connect', array(
      array(
        'methods'   => 'GET',
        'callback'  => array($this, 'fb_connect'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/sms_login', array(
      array(
        'methods'   => 'GET',
        'callback'  => array($this, 'sms_login'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/phone_login', array(
      array(
        'methods'   => \WP_REST_Server::CREATABLE,
        'callback'  => array($this, 'phone_login'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/apple_login', array(
      array(
        'methods'   => 'GET',
        'callback'  => array($this, 'apple_login'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/google_login', array(
      array(
        'methods'   => 'GET',
        'callback'  => array($this, 'google_login'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/post_comment', array(
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'post_comment'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/get_currentuserinfo', array(
      array(
        'methods'   => 'GET',
        'callback'  => array($this, 'get_currentuserinfo'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/get_points', array(
      array(
        'methods'   => 'GET',
        'callback'  => array($this, 'get_points'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/update_user_data', array(
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'update_user_data'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/delete_user', array(
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'delete_user'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/checkout', array(
      array(
        'methods'   => 'GET',
        'callback'  => array($this, 'checkout'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/login_and_redirect', array(
      array(
        'methods'   => 'GET',
        'callback'  => array($this, 'login_and_redirect'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/get_currency_rates', array(
      array(
        'methods'   => 'GET',
        'callback'  => array($this, 'get_currency_rates'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/get_countries', array(
      array(
        'methods'   => 'GET',
        'callback'  => array($this, 'get_countries'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/get_states', array(
      array(
        'methods'   => 'GET',
        'callback'  => array($this, 'get_states'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/test_push_notification', array(
      array(
        'methods'   => 'POST',
        'callback'  => array($this, 'test_push_notification'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));
  }

  /**
   * @param \WP_REST_Request $request
   */
  public function get_user($request)
  {
    try {
      $user_id = $request->get_param('user_id');
      $user = get_user_by('id', $user_id);
      if (false == $user) {
        return parent::sendError('not_found', 'The user could not be found', 400);
      }
      return new WP_REST_Response($this->getResponseUserInfo($user));
    } catch (\Throwable $th) {
      return parent::sendError('user_not_found', $th->getMessage(), $th->getCode());
    }
  }

  public function checkout($request)
  {
    $jwt = $request['jwt'];
    $query_params = $request->get_query_params();
    if (empty($jwt)) {
      $url = wc_get_checkout_url();
      wp_redirect(add_query_arg($query_params, $url));
      exit;
    }

    $secret_key = get_option('woostore_pro_api_secret_jwt_key');
    // $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;

    /** First thing, check the secret key if not exist return a error*/
    if (!$secret_key || empty($secret_key)) {
      return parent::sendError(
        'jwt_auth_bad_config',
        'JWT is not configurated properly, please contact the admin',
        403
      );
    }

    try {
      // This is the data payload
      $d = JWT::decode($jwt, $secret_key, array('HS256'));
      $user_id = $d->data->user->id;

      // after the user_id is available, set the user as current user
      if (empty($user_id)) {
        return parent::sendError('invalid_token', 'Could not find the user', 404);
      }

      wp_set_current_user($user_id);
      wp_set_auth_cookie($user_id);
      $user = wp_get_current_user();
      do_action('wp_login', $user->user_login, $user);
      $url = wc_get_checkout_url();
      wp_redirect(add_query_arg($query_params, $url));
      exit;
    } catch (\Throwable $th) {
      return parent::sendError(
        'jwt_auth_bad_config',
        $th->getMessage(),
        403
      );
    }
  }

  public function login_and_redirect($request)
  {
    $query_params = $request->get_query_params();
    $jwt = $query_params['jwt'];
    $redirect_url = $query_params['redirect_url'];
    if (empty($jwt)) {
      wp_redirect(add_query_arg($query_params, $redirect_url));
      exit;
    }

    $secret_key = get_option('woostore_pro_api_secret_jwt_key');

    /** First thing, check the secret key if not exist return a error*/
    if (!$secret_key || empty($secret_key)) {
      return parent::sendError(
        'jwt_auth_bad_config',
        'JWT is not configurated properly, please contact the admin',
        403
      );
    }

    try {
      // This is the data payload
      $d = JWT::decode($jwt, $secret_key, array('HS256'));
      $user_id = $d->data->user->id;

      // after the user_id is available, set the user as current user
      if (empty($user_id)) {
        return parent::sendError('invalid_token', 'Could not find the user', 404);
      }

      wp_set_current_user($user_id);
      wp_set_auth_cookie($user_id);
      $user = wp_get_current_user();
      do_action('wp_login', $user->user_login, $user);
      wp_redirect(add_query_arg($query_params, $redirect_url));
      exit;
    } catch (\Throwable $th) {
      return parent::sendError(
        'jwt_auth_bad_config',
        $th->getMessage(),
        403
      );
    }
  }

  public function reset_password()
  {
    $json = file_get_contents('php://input');
    $params = json_decode($json, TRUE);
    $usernameReq = $params["user_login"];

    // $errors = new WP_Error();
    if (empty($usernameReq) || !is_string($usernameReq)) {
      return parent::sendError("empty_username", "Enter a username or email address.", 400);
    } elseif (strpos($usernameReq, '@')) {
      $user_data = get_user_by('email', trim(wp_unslash($usernameReq)));
      if (empty($user_data)) {
        return parent::sendError("invalid_email", "There is no account with that username or email address.", 404);
      }
    } else {
      $login     = trim($usernameReq);
      $user_data = get_user_by('login', $login);
    }
    if (!$user_data) {
      return parent::sendError("invalid_email", "There is no account with that username or email address.", 404);
    }

    $user_login = $user_data->user_login;
    $user_email = $user_data->user_email;
    $key        = get_password_reset_key($user_data);

    if (is_wp_error($key)) {
      return $key;
    }

    if (is_multisite()) {
      $site_name = get_network()->site_name;
    } else {
      $site_name = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);
    }

    $message = __('Someone has requested a password reset for the following account:') . "\r\n\r\n";
    $message .= sprintf(__('Site Name: %s'), $site_name) . "\r\n\r\n";
    $message .= sprintf(__('Username: %s'), $user_login) . "\r\n\r\n";
    $message .= __('If this was a mistake, just ignore this email and nothing will happen.') . "\r\n\r\n";
    $message .= __('To reset your password, visit the following address:') . "\r\n\r\n";
    $message .= '<' . network_site_url("wp-login.php?action=rp&key=$key&login=" . rawurlencode($user_login), 'login') . ">\r\n";
    $title = sprintf(__('[%s] Password Reset'), $site_name);
    $title = apply_filters('retrieve_password_title', $title, $user_login, $user_data);
    $message = apply_filters('retrieve_password_message', $message, $key, $user_login, $user_data);

    if ($message && !wp_mail($user_email, wp_specialchars_decode($title), $message)) {
      return parent::sendError("retrieve_password_email_failure", "The email could not be sent. Your site may not be correctly configured to send emails.", 401);
    }

    return new WP_REST_Response(array(
      'status' => 'success',
    ), 200);;
  }

  public function register()
  {
    $json = file_get_contents('php://input');
    $params = json_decode($json, TRUE);
    if (isset($params["role"])) {
      if ($params["role"] != "subscriber" || $params["role"] != "customer") {
        return parent::sendError("invalid_role", "Role is invalid.", 400);
      }
    } else {
      $params['role'] = 'customer';
    }

    $usernameReq = $params["user_login"];
    $emailReq = $params["user_email"];
    $userPassReq = $params["user_pass"];

    // Sanitize the values
    $email = sanitize_email($emailReq);

    if (isset($params["seconds"])) {
      $seconds = (int) $params["seconds"];
    } else {
      $seconds = 120960000;
    }

    if (!validate_username($usernameReq)) {
      return parent::sendError("invalid_username", "Username is invalid.", 400);
    } elseif (username_exists($usernameReq)) {
      return parent::sendError("existed_username", "Username already exists.", 400);
    } elseif (email_exists($email)) {
      return parent::sendError("existed_email", "E-mail address is already in use.", 400);
    } else {
      if (!$userPassReq) {
        $params->user_pass = wp_generate_password();
      }

      $allowed_params = array(
        'user_login', 'user_email', 'user_pass', 'display_name', 'user_nicename', 'user_url', 'nickname', 'first_name',
        'last_name', 'description', 'rich_editing', 'user_registered', 'role', 'jabber', 'aim', 'yim',
        'comment_shortcuts', 'admin_color', 'use_ssl', 'show_admin_bar_front',
      );

      $dataRequest = $params;
      foreach ($dataRequest as $field => $value) {
        if (in_array($field, $allowed_params)) {
          $user[$field] = trim(sanitize_text_field($value));
        }
      }

      $user['role'] = isset($params["role"]) ? sanitize_text_field($params["role"]) : get_option('default_role');

      // set the value of the phone info
      $phone_number = $params['phone'];
      $country_code  = '';
      $use_digits_plugin = false;

      // before inserting user, check if the phone info is provided
      // if yes, check if the digits plugin is to be used
      // if yes check the permission to create user with the digits plugin
      if (isset($params['extra_data'])) {
        $extra_data = $params['extra_data'];
        if (isset($extra_data['use_digits_plugin'])) {
          $use_digits_plugin = (bool)$extra_data['use_digits_plugin'];
        }
        if (isset($extra_data['country_code'])) {
          $country_code = $extra_data['country_code'];
        }
        if (isset($extra_data['phone_number'])) {
          $phone_number = $extra_data['phone_number'];
        }
      }

      if ($use_digits_plugin === true) {
        // check for permissions from digits plugin
        $can_create_user = $this->digit_can_create_user($phone_number, $country_code);
        if (is_wp_error($can_create_user)) {
          return $can_create_user;
        }
      }

      $user_id = wp_insert_user($user);

      if (is_wp_error($user_id)) {
        return parent::sendError($user_id->get_error_code(), $user_id->get_error_message(), 400);
      } else {
        // update the user meta data after user created
        if (!empty($phone_number)) {
          $this->update_user_phone_info(
            $user_id,
            $country_code,
            $phone_number,
            $use_digits_plugin,
          );
        }
        wp_new_user_notification($user_id, '', '');
      }
    }

    $cookie = $this->generateCookieByUserId($user_id);
    $jwt_auth_token = $this->generate_jwt_auth_token($user_id);

    return array(
      "cookie" => $cookie,
      "user_id" => $user_id,
      "jwt_token" => $jwt_auth_token,
    );
  }

  private function get_shipping_address($userId)
  {
    $shipping = [];

    $shipping["first_name"] = get_user_meta($userId, 'shipping_first_name', true);
    $shipping["last_name"] = get_user_meta($userId, 'shipping_last_name', true);
    $shipping["company"] = get_user_meta($userId, 'shipping_company', true);
    $shipping["address_1"] = get_user_meta($userId, 'shipping_address_1', true);
    $shipping["address_2"] = get_user_meta($userId, 'shipping_address_2', true);
    $shipping["city"] = get_user_meta($userId, 'shipping_city', true);
    $shipping["state"] = get_user_meta($userId, 'shipping_state', true);
    $shipping["postcode"] = get_user_meta($userId, 'shipping_postcode', true);
    $shipping["country"] = get_user_meta($userId, 'shipping_country', true);
    $shipping["email"] = get_user_meta($userId, 'shipping_email', true);
    $shipping["phone"] = get_user_meta($userId, 'shipping_phone', true);

    if (empty($shipping["first_name"]) && empty($shipping["last_name"]) && empty($shipping["company"]) && empty($shipping["address_1"]) && empty($shipping["address_2"]) && empty($shipping["city"]) && empty($shipping["state"]) && empty($shipping["postcode"]) && empty($shipping["country"]) && empty($shipping["email"]) && empty($shipping["phone"])) {
      return null;
    }
    return $shipping;
  }

  private function get_billing_address($userId)
  {
    $billing = [];

    $billing["first_name"] = get_user_meta($userId, 'billing_first_name', true);
    $billing["last_name"] = get_user_meta($userId, 'billing_last_name', true);
    $billing["company"] = get_user_meta($userId, 'billing_company', true);
    $billing["address_1"] = get_user_meta($userId, 'billing_address_1', true);
    $billing["address_2"] = get_user_meta($userId, 'billing_address_2', true);
    $billing["city"] = get_user_meta($userId, 'billing_city', true);
    $billing["state"] = get_user_meta($userId, 'billing_state', true);
    $billing["postcode"] = get_user_meta($userId, 'billing_postcode', true);
    $billing["country"] = get_user_meta($userId, 'billing_country', true);
    $billing["email"] = get_user_meta($userId, 'billing_email', true);
    $billing["phone"] = get_user_meta($userId, 'billing_phone', true);

    if (empty($billing["first_name"]) && empty($billing["last_name"]) && empty($billing["company"]) && empty($billing["address_1"]) && empty($billing["address_2"]) && empty($billing["city"]) && empty($billing["state"]) && empty($billing["postcode"]) && empty($billing["country"]) && empty($billing["email"]) && empty($billing["phone"])) {
      return null;
    }

    return $billing;
  }

  function getResponseUserInfo($user)
  {
    $shipping = $this->get_shipping_address($user->ID);
    $billing = $this->get_billing_address($user->ID);

    $avatar_url = get_avatar_url($user->ID);

    if ($avatar_url === false) {
      $avatar_url = '';
    }

    $phone = (string)get_user_meta($user->ID, 'woostore_pro_registered_phone_number', true);
    $digits_phone = '';
    if ($this->is_digits_plugin_installed()) {
      if (function_exists('digits_get_mobile')) {
        $val = digits_get_mobile($user->ID);
        if (!empty($val)) {
          $digits_phone = $val;
        }
      }
    }

    return array(
      "id" => $user->ID,
      "username" => $user->user_login,
      "nicename" => $user->user_nicename,
      "email" => $user->user_email,
      "url" => $user->user_url,
      "registered" => $user->user_registered,
      "displayname" => $user->display_name,
      "firstname" => $user->user_firstname,
      "lastname" => $user->last_name,
      "first_name" => $user->first_name,
      "last_name" => $user->last_name,
      "nickname" => $user->nickname,
      "description" => $user->user_description,
      "capabilities" => $user->wp_capabilities,
      "shipping" => $shipping,
      "billing" => $billing,
      "avatar_url" => $avatar_url,
      "phone" => $phone,
      "digits_phone" => $digits_phone
    );
  }

  public function authenticate()
  {
    $json = file_get_contents('php://input');
    $params = json_decode($json, TRUE);
    if (!isset($params["email"]) || !isset($params["password"])) {
      return parent::sendError("invalid_login", "Invalid params", 400);
    }
    $email = $params["email"];
    $password = $params["password"];

    $user = wp_authenticate($email, $password);

    if (is_wp_error($user)) {
      return parent::sendError($user->get_error_code(), "Invalid email or password.", 401);
    }

    $cookie = $this->generateCookieByUserId($user->ID);
    $jwt_auth_token = $this->generate_jwt_auth_token($user->ID);

    return array(
      "cookie" => $cookie,
      "cookie_name" => LOGGED_IN_COOKIE,
      "user" => $this->getResponseUserInfo($user),
      "jwt_token" => $jwt_auth_token,
    );
  }

  public function generate_auth_cookie()
  {
    $json = file_get_contents('php://input');
    $params = json_decode($json, TRUE);
    if (!isset($params["email"]) || !isset($params["password"])) {
      return parent::sendError("invalid_login", "Invalid params", 400);
    }
    $email = $params["email"];
    $password = $params["password"];
    $seconds = 12096000;

    $user = wp_authenticate($email, $password);

    if (is_wp_error($user)) {
      return parent::sendError($user->get_error_code(), "Invalid email or password.", 401);
    }

    $tempTime = apply_filters('auth_cookie_expiration', $seconds, $user->ID, true);
    $expiration = time() + (int) $tempTime;
    $cookie = wp_generate_auth_cookie($user->ID, $expiration, 'logged_in');

    return array(
      "cookie" => $cookie,
      "cookie_name" => LOGGED_IN_COOKIE,
      "user" => $this->getResponseUserInfo($user),
    );
  }


  function generate_jwt_auth_token($user_id)
  {
    $secret_key = get_option('woostore_pro_api_secret_jwt_key');
    // $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : false;

    /** First thing, check the secret key if not exist return a error*/
    if (!$secret_key) {
      return new WP_Error(
        'jwt_auth_bad_config',
        'JWT is not configurated properly, please contact the admin',
        array(
          'status' => 403,
        )
      );
    }

    /** Valid credentials, the user exists create the according Token */
    $issuedAt = time();
    $notBefore = apply_filters('jwt_auth_not_before', $issuedAt, $issuedAt);
    $expire = apply_filters('jwt_auth_expire', $issuedAt + (MONTH_IN_SECONDS * 2), $issuedAt);

    $token = array(
      'iss' => get_bloginfo('url'),
      'iat' => $issuedAt,
      'nbf' => $notBefore,
      'exp' => $expire,
      'data' => array(
        'user' => array(
          'id' => $user_id,
        ),
      ),
    );
    /** Let the user modify the token data before the sign. */
    $auth_token = JWT::encode($token, $secret_key);
    return $auth_token;
  }

  /**
   * @param string $email
   * @param string $name
   * @param string $firstName
   * @param string $lastName
   * @param string $userName
   * @param array $phone_info
   */
  function createSocialAccount($email, $name, $firstName, $lastName, $userName, $phone_info = array())
  {
    $email_exists = email_exists($email);
    if ($email_exists) {
      $user = get_user_by('email', $email);
      $user_id = $user->ID;
    } else {
      $i = 0;
      while (username_exists($userName) !== false) {
        $i++;
        $userName = strtolower($userName) . '.' . $i;
      }
      $random_password = wp_generate_password($length = 12, $include_standard_special_chars = false);
      $userdata = array(
        'user_login'    => $userName,
        'user_email'    => $email,
        'user_pass'  => $random_password,
        'display_name'  => $name,
        'first_name'  => $firstName,
        'last_name'  => $lastName,
        'role' => 'customer'
      );
      $user_id = wp_insert_user($userdata);
    }

    if (is_wp_error($user_id)) {
      return parent::sendError($user_id->get_error_code(), $user_id->get_error_message(), 400);
    } else {
      // user was created successfully so add the phone number to their account
      if (isset($phone_info) && is_array($phone_info) && isset($phone_info['phone_number'])) {
        $this->update_user_phone_info(
          $user_id,
          $phone_info['country_code'],
          $phone_info['phone_number'],
          $phone_info['use_digits_plugin']
        );
      }
    }

    // $tempTime = apply_filters('auth_cookie_expiration', 1209600, $user_id, true);
    // $expiration = time() + (int) $tempTime;
    $expiration = time() + 365 * DAY_IN_SECONDS;

    $cookie = wp_generate_auth_cookie($user_id, $expiration, 'logged_in');
    $user = get_userdata($user_id);
    $jwt_auth_token = $this->generate_jwt_auth_token($user_id);

    $response['wp_user_id'] = $user_id;
    $response['cookie'] = $cookie;
    $response['jwt_token'] = $jwt_auth_token;
    $response['user_login'] = $user->user_login;
    $response['user'] = $this->getResponseUserInfo($user);
    return $response;
  }

  public function fb_connect($request)
  {
    $fields = 'id,name,first_name,last_name,email';
    $access_token = $request["access_token"];
    if (!isset($access_token)) {
      return parent::sendError("invalid_token", "You must include an 'access_token' variable. Get the valid access_token for this app from Facebook API.", 400);
    }
    $url = 'https://graph.facebook.com/me/?fields=' . $fields . '&access_token=' . $access_token;

    $result = wp_remote_retrieve_body(wp_remote_get($url));

    $result = json_decode($result, true);

    if (isset($result["email"])) {
      $user_name = strtolower($result['first_name'] . '.' . $result['last_name']);
      if (strlen($user_name) < 3) {
        $user_name = str_replace('@', '.', $result["email"]);
      }
      return $this->createSocialAccount($result["email"], $result['name'], $result['first_name'], $result['lastname_name'], $user_name);
    } else {
      return parent::sendError("invalid_email", "Your 'access_token' did not return email of the user. Without 'email' user can't be logged in or registered. Get user email extended permission while joining the Facebook app.", 400);
    }
  }

  /**
   * @deprecated
   */
  public function sms_login($request)
  {
    $access_token = $request["access_token"];
    if (!isset($access_token)) {
      return parent::sendError("invalid_login", "You must include a 'access_token' variable. Get the valid access_token for this app from Facebook API.", 400);
    }
    $url = 'https://graph.accountkit.com/v1.3/me/?access_token=' . $access_token;

    $WP_Http_Curl = new \WP_Http_Curl();
    $result = $WP_Http_Curl->request($url, array(
      'method'      => 'GET',
      'timeout'     => 5,
      'redirection' => 5,
      'httpversion' => '1.0',
      'blocking'    => true,
      'headers'     => array(),
      'body'        => null,
      'cookies'     => array(),
    ));

    $result = json_decode($result, true);

    if (isset($result["phone"])) {
      $user_name = $result["phone"]["number"];
      $user_email = $result["phone"]["number"] . "@flutter.io";
      return $this->createSocialAccount($user_email, $user_name, $user_name, "", $user_name);
    } else {
      return parent::sendError("invalid_login", "Your 'access_token' did not return email of the user. Without 'email' user can't be logged in or registered. Get user email extended permission while joining the Facebook app.", 400);
    }
  }

  /**
   * @param WP_REST_Request $request
   */
  public function phone_login($request)
  {
    $params = $request->get_params();
    $country_code = $params['country_code'];
    $phone_number = $params["phone_number"];
    $phone = $params["phone"]; // full phone value
    $use_digits_plugin = (bool)$params['use_digits_plugin'];
    if (!isset($phone)) {
      return parent::sendError("invalid_login", "You must include a 'phone' number.", 400);
    }

    // if digits plugin is enabled, search for the user based on the digits meta fields
    // if you find the user, update the woostore pro registered phone number meta field for the
    // user and return the user
    //
    // if the user is not found in the digits records, then find in the woostore pro registered phone number
    // meta field, if user is found, then udpate the digits meta fields if the plugin support
    // is enabled, finally send the user info
    //
    // if the user is not found, then create the user

    // empty array to add search result data
    $search_users = array();

    if ($use_digits_plugin) {
      if ($this->is_digits_plugin_installed()) {
        // search for users
        $args = array('meta_key' => 'digits_phone', 'meta_value' => $country_code . $phone_number);
        $search_users = get_users($args);
      } else {
        return parent::sendError('missing_plugin', 'Enabled Phone login throug Digits Plugin but the plugin is not active.', 400);
      }
    }

    if (empty($search_users)) {
      // find the user with the woostore pro phone number meta field
      $args = array('meta_key' => 'woostore_pro_registered_phone_number', 'meta_value' => $phone);
      $search_users = get_users($args);
    }

    if (empty($search_users)) {
      $domain = $_SERVER['SERVER_NAME'];
      if (count(explode(".", $domain)) == 1) {
        $domain = "flutter.io";
      }
      $user_name = $phone_number;
      $user_email = $phone_number . "@" . $domain;
      $user = get_user_by('email', $user_email);
      if ($user === false) {
        if ($use_digits_plugin) {
          // check all the digit plugins required parameters before creating the user
          $can_create_user = $this->digit_can_create_user($phone_number, $country_code);
          if (is_wp_error($can_create_user)) {
            return $can_create_user;
          }
        }

        return $this->createSocialAccount(
          $user_email,
          $user_name,
          $user_name,
          "",
          $user_name,
          array(
            'phone_number' => $phone_number,
            'country_code' => $country_code,
            "use_digits_plugin" => $use_digits_plugin
          )
        );
      } else {
        // this means that we found the user but there was no entry for the phone
        // number, therefore update the phone numbers for the user
        $this->update_user_phone_info(
          $user->ID,
          $country_code,
          $phone_number,
          $use_digits_plugin
        );
      }

      $user_id = $user->ID;
      $cookie = $this->generateCookieByUserId($user_id);
      $jwt_auth_token = $this->generate_jwt_auth_token($user_id);
      $response['wp_user_id'] = $user->ID;
      $response['cookie'] = $cookie;
      $response['jwt_token'] = $jwt_auth_token;
      $response['user_login'] = $user->user_login;
      $response['user'] = $this->getResponseUserInfo($user);
      return $response;
    }

    if (count($search_users) > 1) {
      return parent::sendError("invalid_login", "Too many users with the same phone number", 400);
    }
    $user = $search_users[0];
    $user_id = $user->ID;
    $cookie = $this->generateCookieByUserId($user_id);
    $jwt_auth_token = $this->generate_jwt_auth_token($user_id);
    $response['wp_user_id'] = $user->ID;
    $response['cookie'] = $cookie;
    $response['jwt_token'] = $jwt_auth_token;
    $response['user_login'] = $user->user_login;
    $response['user'] = $this->getResponseUserInfo($user);
    return $response;
    return parent::sendError("invalid_login", "Unknown Error", 400);
  }

  function jwtDecode($token)
  {
    $splitToken = explode(".", $token);
    $payloadBase64 = $splitToken[1]; // Payload is always the index 1
    $decodedPayload = json_decode(urldecode(base64_decode($payloadBase64)), true);
    return $decodedPayload;
  }

  public function apple_login($request)
  {
    $email = $request['email'];
    $display_name = $request['display_name'];
    $user_name = $request['user_name'];
    if (strlen($user_name) < 3) {
      $user_name = str_replace('@', '.', $email);
    }
    if (!isset($email)) {
      return parent::sendError("invalid_email", "Can't get the email to create account.", 400);
    }
    return $this->createSocialAccount($email, $display_name, $display_name, "", $user_name);
  }

  public function google_login($request)
  {
    $access_token = $request["access_token"];
    if (!isset($access_token)) {
      return parent::sendError("invalid_token", "You must include an 'access_token' variable. Get the valid access_token for this app from Google API.", 400);
    }

    $url = 'https://www.googleapis.com/oauth2/v1/userinfo?alt=json&access_token=' . $access_token;

    $result = wp_remote_retrieve_body(wp_remote_get($url));

    $result = json_decode($result, true);
    if (isset($result["email"])) {
      $firstName = $result["given_name"];
      $lastName = $result["family_name"];
      $email = $result["email"];
      $display_name = $firstName . " " . $lastName;
      $user_name = $firstName . '.' . $lastName;
      if (strlen($user_name) < 3) {
        $user_name = str_replace('@', '.', $email);
      }
      return $this->createSocialAccount($email, $display_name, $firstName, $lastName, $user_name);
    } else {
      return parent::sendError("invalid_email", "Your 'token' did not return email of the user. Without 'email' user can't be logged in or registered. Get user email extended permission while joining the Google app.", 400);
    }
  }

  /*
     * Post commment function
     */
  public function post_comment($request)
  {
    $cookie = $request["cookie"];
    if (!isset($cookie)) {
      return parent::sendError("invalid_auth_token", "You must include a 'cookie' var in your request. Use the `generate_auth_cookie` method.", 401);
    }
    $user_id = wp_validate_auth_cookie($cookie, 'logged_in');
    if (!$user_id) {
      return parent::sendError("invalid_token", "Could not veriy your identity. Please login again.", 401);
    }

    $rc = new \WC_REST_Product_Reviews_Controller();
    return $rc->create_item($request);
  }

  public function get_currentuserinfo($request)
  {
    $cookie = $request["cookie"];
    if (isset($request["token"])) {
      $cookie = urldecode(base64_decode($request["token"]));
    }
    if (!isset($cookie)) {
      return parent::sendError("invalid_login", "You must include a 'cookie' var in your request. Use the `generate_auth_cookie` method.", 401);
    }

    $user_id = wp_validate_auth_cookie($cookie, 'logged_in');
    if (!$user_id) {
      return parent::sendError("invalid_token", "Could not veriy your identity. Please login again.", 401);
    }
    $user = get_userdata($user_id);
    return array(
      "user" => $this->getResponseUserInfo($user)
    );
  }

  function update_user_data()
  {
    $json = file_get_contents('php://input');
    $params = json_decode($json);
    $cookie = $params->cookie;
    if (!isset($cookie)) {
      return parent::sendError("invalid_login", "You must include a 'cookie' var in your request. Use the `generate_auth_cookie` method.", 401);
    }
    $user_id = wp_validate_auth_cookie($cookie, 'logged_in');
    if (!$user_id) {
      return parent::sendError("invalid_token", "Could not veriy your identity. Please login again.", 401);
    }

    $user_update = array('ID' => $user_id);
    if (isset($params->first_name)) {
      $user_update['first_name'] = $params->first_name;
      update_user_meta($user_id, 'billing_first_name', $params->first_name, '');
    }
    if (isset($params->last_name)) {
      $user_update['last_name'] = $params->last_name;
      update_user_meta($user_id, 'billing_last_name', $params->last_name, '');
    }
    if (isset($params->user_pass)) {
      $user_update['user_pass'] = $params->user_pass;
    }
    if (isset($params->user_nicename)) {
      $user_update['user_nicename'] = $params->user_nicename;
    }
    if (isset($params->user_email)) {
      $user_update['user_email'] = $params->user_email;
    }
    if (isset($params->user_url)) {
      $user_update['user_url'] = $params->user_url;
    }
    if (isset($params->display_name)) {
      $user_update['display_name'] = $params->display_name;
    }

    // update shipping information
    if (isset($params->shipping)) {
      $shipping_map = $params->shipping;
      if (isset($shipping_map->company)) {
        update_user_meta($user_id, 'shipping_company', $shipping_map->company, '');
      }
      if (isset($shipping_map->state)) {
        update_user_meta($user_id, 'shipping_state', $shipping_map->state, '');
      }
      if (isset($shipping_map->address_1)) {
        update_user_meta($user_id, 'shipping_address_1', $shipping_map->address_1, '');
      }
      if (isset($shipping_map->address_2)) {
        update_user_meta($user_id, 'shipping_address_2', $shipping_map->address_2, '');
      }
      if (isset($shipping_map->city)) {
        update_user_meta($user_id, 'shipping_city', $shipping_map->city, '');
      }
      if (isset($shipping_map->country)) {
        update_user_meta($user_id, 'shipping_country', $shipping_map->country, '');
      }
      if (isset($shipping_map->postcode)) {
        update_user_meta($user_id, 'shipping_postcode', $shipping_map->postcode, '');
      }
    }

    // update billing information
    if (isset($params->billing)) {
      $billing_map = $params->billing;
      if (isset($billing_map->email)) {
        update_user_meta($user_id, 'billing_email', $billing_map->email, '');
      }
      if (isset($billing_map->phone)) {
        update_user_meta($user_id, 'billing_phone', $billing_map->phone, '');
      }
      if (isset($billing_map->company)) {
        update_user_meta($user_id, 'billing_company', $billing_map->company, '');
      }
      if (isset($billing_map->state)) {
        update_user_meta($user_id, 'billing_state', $billing_map->state, '');
      }
      if (isset($billing_map->address_1)) {
        update_user_meta($user_id, 'billing_address_1', $billing_map->address_1, '');
      }
      if (isset($billing_map->address_2)) {
        update_user_meta($user_id, 'billing_address_2', $billing_map->address_2, '');
      }
      if (isset($billing_map->city)) {
        update_user_meta($user_id, 'billing_city', $billing_map->city, '');
      }
      if (isset($billing_map->country)) {
        update_user_meta($user_id, 'billing_country', $billing_map->country, '');
      }
      if (isset($billing_map->postcode)) {
        update_user_meta($user_id, 'billing_postcode', $billing_map->postcode, '');
      }
    }

    if (isset($params->deviceToken)) {
      update_user_meta($user_id, 'woostore_pro_device_token', $params->deviceToken);
      // update_option("woostore_pro_device_token_" . $user_id, $params->deviceToken);
    }

    if (isset($params->phone_info)) {
      $phone_info = $params->phone_info;
      $this->update_user_phone_info(
        $user_id,
        $phone_info->country_code,
        $phone_info->phone_number,
        $phone_info->use_digits_plugin
      );
    } else {
      if (isset($params->phone)) {
        $this->update_user_phone_info(
          $user_id,
          '',
          $params->phone,
          false
        );
      }
    }

    try {
      $user_data = wp_update_user($user_update);
      if (is_wp_error($user_data)) {
        return parent::sendError($user_data->code, $user_data->message, '401');
      }
      $user = get_userdata($user_id);
      return $this->getResponseUserInfo($user);
    } catch (\Exception $e) {
      return parent::sendError($e->getCode(), $e->getMessage(), '500');
    }
  }

  public function change_password()
  {
    $json = file_get_contents('php://input');
    $params = json_decode($json);
    $cookie = $params->cookie;
    if (!isset($cookie)) {
      return parent::sendError("missing_cookie", "You must include a 'cookie' var in your request. Use the `generate_auth_cookie` method.", 401);
    }
    $user_id = wp_validate_auth_cookie($cookie, 'logged_in');
    if (!$user_id) {
      return parent::sendError("invalid_token", "Could not veriy your identity. Please login again.", 401);
    }

    $user_update = array('ID' => $user_id);
    if (isset($params->password)) {
      $user_update['user_pass'] = $params->password;
    }

    $u = wp_update_user($user_update);
    if (is_wp_error($u)) {
      return parent::sendError($u->code, $u->message, '401');
    }

    $cookie = $this->generateCookieByUserId($user_id);
    $jwt_auth_token = $this->generate_jwt_auth_token($user_id);

    return array(
      'cookie' => $cookie,
      'jwt_token' => $jwt_auth_token,
    );
  }

  public function change_password_v2()
  {
    $json = file_get_contents('php://input');
    $params = json_decode($json);

    $old_password = $params->old_password;
    $email = $params->email;

    $user = wp_authenticate($email, $old_password);
    if (is_wp_error($user)) {
      return parent::sendError($user->get_error_code(), "Invalid email or password.", 401);
    }

    $user_id = $user->ID;
    $user_update = array('ID' => $user_id);
    if (isset($params->password)) {
      $user_update['user_pass'] = $params->password;
    }

    $u = wp_update_user($user_update);
    if (is_wp_error($u)) {
      return parent::sendError($u->code, $u->message, '401');
    }

    $cookie = $this->generateCookieByUserId($user_id);
    $jwt_auth_token = $this->generate_jwt_auth_token($user_id);

    return array(
      'cookie' => $cookie,
      'jwt_token' => $jwt_auth_token,
    );
  }

  function prepare_checkout()
  {
    global $json_api;
    $json = file_get_contents('php://input');
    $params = json_decode($json);
    $order = $params->order;
    if (!isset($order)) {
      return parent::sendError("invalid_checkout", "You must include a 'order' var in your request", 400);
    }
    global $wpdb;
    $table_name = $wpdb->prefix . "woostore_pro_checkout";

    $code = md5(mt_rand() . strtotime("now"));
    $success = $wpdb->insert(
      $table_name,
      array(
        'code' => $code,
        'order' => $order
      )
    );
    if ($success) {
      return $code;
    } else {
      return parent::sendError("error_insert_database", "Can't insert to database", 400);
    }
  }

  public function get_currency_rates()
  {
    global $woocommerce_wpml;

    if (!empty($woocommerce_wpml->multi_currency) && !empty($woocommerce_wpml->settings['currencies_order'])) {
      return $woocommerce_wpml->settings['currency_options'];
    }
    return parent::sendError("not_install_woocommerce_wpml", "WooCommerce WPML hasn't been installed yet.", 404);
  }

  public function get_countries()
  {
    $wc_countries = new \WC_Countries();
    $array = $wc_countries->get_countries();
    $keys = array_keys($array);
    $countries = array();
    for ($i = 0; $i < count($keys); $i++) {
      $countries[] = ["code" => $keys[$i], "name" => $array[$keys[$i]]];
    }
    return $countries;
  }

  public function get_states($request)
  {
    $wc_countries = new \WC_Countries();
    $array = $wc_countries->get_states($request["country_code"]);
    if ($array) {
      $keys = array_keys($array);
      $states = array();
      for ($i = 0; $i < count($keys); $i++) {
        $states[] = ["code" => $keys[$i], "name" => $array[$keys[$i]]];
      }
      return $states;
    } else {
      return [];
    }
  }

  /**
   * Get Point Reward by User ID
   *
   * @return void
   */
  function get_points($request)
  {
    global $wc_points_rewards;
    $user_id = (int) $request['user_id'];
    $current_page = (int) $request['page'];

    if (!class_exists("WC_Points_Rewards_Manager")) {
      return parent::sendError('missing_plugin', 'Woocommerce Points and Rewards Plugin is not installed or is not active', 500);
    }

    $points_balance = \WC_Points_Rewards_Manager::get_users_points($user_id);
    $points_label   = $wc_points_rewards->get_points_label($points_balance);
    $count        = apply_filters('wc_points_rewards_my_account_points_events', 5, $user_id);
    $current_page = empty($current_page) ? 1 : absint($current_page);

    $args = array(
      'calc_found_rows' => true,
      'orderby' => array(
        'field' => 'date',
        'order' => 'DESC',
      ),
      'per_page' => $count,
      'paged'    => $current_page,
      'user'     => $user_id,
    );
    $events = \WC_Points_Rewards_Points_Log::get_points_log_entries($args);

    return array(
      'points_balance' => $points_balance,
      'points_label'   => $points_label,
      'page'   => $current_page,
      'count'          => $count,
      'events'         => $events
    );
  }

  public function test_push_notification()
  {
    $json = file_get_contents('php://input');
    $params = json_decode($json);
    $email = $params->email;
    $user = get_user_by('email', $email);
    $user_id = $user->ID;
    // $deviceToken = get_option("woostore_pro_device_token_" . $user_id);
    $deviceToken = get_user_meta($user_id, "woostore_pro_device_token");
    $serverKey = get_option("woostore_pro_firebase_server_key");
    $status = false;
    if ($deviceToken) {
      $status = pushNotification("WooStore Pro Ecommerce App", "Test push notification", $deviceToken);
    }
    return ["deviceToken" => $deviceToken, 'serverKey' => $serverKey, 'status' => $status];
  }

  function generateCookieByUserId($user_id, $seconds = 1209600)
  {
    $tempTime = apply_filters('auth_cookie_expiration', $seconds, $user_id, true);
    $expiration = time() + (int)$tempTime;
    $cookie = wp_generate_auth_cookie($user_id, $expiration, 'logged_in');
    return $cookie;
  }

  /**
   * @param WP_REST_Request $request
   * @return bool|WP_Error 
   */
  public function delete_user($request)
  {
    try {
      $params = $request->get_params();
      $email = $params['email'];
      $password = $params['password'];
      if ($email === null || empty($email)) {
        return parent::sendError('invalid_params', 'The paramenter "email" cannot be empty', 400);
      }

      if ($password === null || empty($password)) {
        return parent::sendError('invalid_params', 'The paramenter "password" cannot be empty', 400);
      }

      // try to authenticate the user
      $user_or_error = wp_authenticate($email, $password);
      if (is_wp_error($user_or_error)) {
        return parent::sendError('invalid_credentials', 'Authentication failed due to invalid email or password', 400, $user_or_error);
      }

      if ($user_or_error instanceof \WP_User) {
        // if all the above tests pass then delete the user
        require_once(ABSPATH . 'wp-admin/includes/user.php');
        $result = wp_delete_user($user_or_error->ID);
        if ($result === true) {
          return new WP_REST_Response(['success' => true]);
        } else {
          return parent::sendError('failed', 'Something went wrong while deleting the user.', 400);
        }
      } else {
        return parent::sendError('user_not_found', 'Could not find the user data related to this email id', 400);
      }
    } catch (\Throwable $th) {
      return parent::sendError('internal_error', $th->getMessage(), 500);
    }
  }

  /**
   * Check if the digits plugin is installed or not
   * @return bool
   */
  function is_digits_plugin_installed()
  {
    return is_plugin_active('digits/digit.php');
  }

  /**
   * @param int $user_id
   * @param string $country_code
   * @param string $phone_number
   * @param bool $use_digits_plugin
   * @return bool|\WP_Error
   */
  function update_user_phone_info($user_id, $country_code, $phone_number, $use_digits_plugin = false)
  {
    try {
      if (isset($country_code) && !empty($country_code)) {
        update_user_meta($user_id, 'billing_phone', $country_code . '-' . $phone_number);
        update_user_meta($user_id, 'woostore_pro_registered_phone_number', $country_code . '-' . $phone_number);
      } else {
        update_user_meta($user_id, 'billing_phone', $phone_number);
        update_user_meta($user_id, 'woostore_pro_registered_phone_number', $phone_number);
      }

      if ($use_digits_plugin !== null && is_bool($use_digits_plugin) && $use_digits_plugin) {
        if ($this->is_digits_plugin_installed()) {

          $can_create_user = $this->digit_can_create_user($phone_number, $country_code);
          if ($can_create_user === true) {
            if (function_exists('digits_update_mobile')) {
              digits_update_mobile($user_id, $country_code, $phone_number);
            }
          }
          if (is_wp_error($can_create_user)) {
            // remove the added value as well
            update_user_meta($user_id, 'billing_phone', '');
            update_user_meta($user_id, 'woostore_pro_registered_phone_number', '');
          }
        }
      }
    } catch (\Throwable $th) {
      parent::sendError('update_user_phone_info_error', $th->getMessage(), 500);
    }
  }

  /**
   * @return bool|\WP_Error
   */
  function digit_can_create_user($phone_number, $country_code)
  {
    // check if the number is allowed
    $users_can_register = get_option('dig_enable_registration', 1);
    if ($users_can_register != 1) {
      return parent::sendError('user_cannot_register_digits_plugin', 'Please ask admin to enable the digits plugin\'s user registration feature', 400);
    }

    if (!checkwhitelistcode($country_code)) {
      return parent::sendError('user_cannot_register_digits_plugin', 'Country is blacklisted by admin', 400);
    }

    if (!dig_is_phone_no_allowed($phone_number)) {
      return parent::sendError('user_cannot_register_digits_plugin', 'Phone Number is not allowed', 400);
    }

    return true;
  }
}
