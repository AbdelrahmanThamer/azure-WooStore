<?php

namespace WOOSTORE_PRO_API\JWT;

class BeforeValidException extends \UnexpectedValueException
{

}
