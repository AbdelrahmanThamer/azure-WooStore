<?php

namespace WOOSTORE_PRO_API\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{

}
