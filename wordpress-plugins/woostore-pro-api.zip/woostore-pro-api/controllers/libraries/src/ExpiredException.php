<?php

namespace WOOSTORE_PRO_API\JWT;

class ExpiredException extends \UnexpectedValueException
{

}
