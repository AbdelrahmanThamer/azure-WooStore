<?php

namespace WooStoreProApi\Controllers;

use WP_REST_Server;

require_once(__DIR__ . '/FlutterBase.php');

class WooStoreFlutterProductController extends WooStoreFlutterBaseController
{

  public function __construct()
  {
    $this->namespace = 'woostore_pro_api/flutter_products';
  }

  public function register_routes()
  {
    register_rest_route($this->namespace, '/get_product_points', array(
      array(
        'methods'   => WP_REST_Server::READABLE,
        'callback'  => array($this, 'get_product_points'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/get-mix-max-prices', array(
      array(
        'methods'   => WP_REST_Server::CREATABLE,
        'callback'  => array($this, 'woostore_pro_get_min_max_prices'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    add_filter('woocommerce_rest_prepare_product_object', array($this, 'update_product_response'), 30, 3);

    add_filter('woocommerce_rest_prepare_product_attribute', array(
      $this,
      'woostore_pro_custom_woocommerce_rest_prepare_product_attribute'
    ), 50, 3);

    // Manipulate the product collection query to get products based on
    // multiple attributes
    add_filter('woocommerce_rest_product_object_query', array(
      $this,
      'woostore_pro_woocommerce_rest_product_object_query',
    ), 10, 2);
  }

  /**
   * @param WP_REST_Response $response
   * @param Array $productData
   * @param WP_REST_Request $request
   * 
   */
  public function update_product_response($response, $productData, $request)
  {
    try {
      $product_addons = \WC_Product_Addons_Helper::get_product_addons($response->data['id'], false);
      // Get images instead of image id in multiple choice
      if (is_array($product_addons)) {
        $modified_product_addons = array();
        // If the multiple choice has images as the display property
        foreach ($product_addons as $addOn) {
          if ($addOn['display'] === 'images') {
            // loop throug the options and change the images ID to image url
            if (is_array($addOn['options'])) {
              foreach ($addOn['options'] as $key => $addOnImageOption) {
                $image_id = (int) $addOnImageOption['image'];
                $image_url = wp_get_attachment_image_url($image_id);
                $options =  array_merge($addOnImageOption, ['image_url' => $image_url]);
                $addOn['options'][$key] = $options;
              }
            }
          }
          $modified_product_addons[] = $addOn;
        }
        $response->data['woostore_pro_product_add_ons'] = $modified_product_addons;
      } else {
        $response->data['woostore_pro_product_add_ons'] = array();
      }

      return $response;
    } catch (\Throwable $th) {
      return $response;
    }
  }

  function woostore_get_add_ons($categories)
  {
    $addOns = [];
    if (is_plugin_active('woocommerce-product-addons/woocommerce-product-addons.php')) {
      $addOnGroup = \WC_Product_Addons_Groups::get_all_global_groups();
      foreach ($addOnGroup as $addOn) {
        $cateIds = array_keys($addOn["restrict_to_categories"]);
        if (count($cateIds) == 0) {
          $addOns = array_merge($addOns, $addOn["fields"]);
          break;
        }
        $isSupported = false;
        foreach ($categories as $cate) {
          if (in_array($cate["id"], $cateIds)) {
            $isSupported = true;
            break;
          }
        }
        if ($isSupported) {
          $addOns = array_merge($addOns, $addOn["fields"]);
        }
      }
    }
    return $addOns;
  }

  // Try to get the points for the product based on the id
  public function get_product_points($request)
  {
    $product_id = (int) $request['product_id'];

    if (empty($product_id)) {
      return parent::sendError('invalid_params', 'The parameters are invalid. Please provide a valid product_id', 400);
    }

    if (!class_exists("WC_Points_Rewards_Product")) {
      return parent::sendError('missing_plugin', 'WooCommerce Points and Rewards Plugin is missing, please contact the admin to resolve this issue', 404);
    }

    try {
      $pc = new \WC_Points_Rewards_Product();
      $points = $pc->get_points_earned_for_product_purchase($product_id);

      if (!is_int($points)) {
        return parent::sendError('not_found', 'Could not find the points for the given product id', 404);
      }

      return array(
        "product_id" => $product_id,
        "points" => $points
      );
    } catch (\Throwable $th) {
      return parent::sendError('not_found', 'Could not find the points for the given product id', 404);
    }
  }

  /**
   * Pre product attribute
   *
   * @param $response
   * @param $item
   * @param $request
   * 
   * @return WP_REST_Response
   */
  public function woostore_pro_custom_woocommerce_rest_prepare_product_attribute($response, $item, $request)
  {

    $taxonomy = wc_attribute_taxonomy_name($item->attribute_name);

    $options = get_terms(array(
      'taxonomy'   => $taxonomy,
      'hide_empty' => false,
    ));

    $terms = $this->woostore_pro_terms($request, $taxonomy);

    foreach ($options as $key => $term) {
      if ($item->attribute_type == 'color') {
        $term->value = sanitize_hex_color(get_term_meta(
          $term->term_id,
          'product_attribute_color',
          true
        ));
      }

      if ($item->attribute_type == 'image') {
        $attachment_id = absint(get_term_meta($term->term_id, 'product_attribute_image', true));
        $image_size    = function_exists('woo_variation_swatches') ? woo_variation_swatches()->get_option('attribute_image_size') : 'thumbnail';

        $term->value = wp_get_attachment_image_url(
          $attachment_id,
          apply_filters('wvs_product_attribute_image_size', $image_size)
        );
      }

      $options[$key] = $term;
    }

    $_terms = array();
    foreach ($terms as $key => $term) {
      $i = array_search($term['term_count_id'], array_column($options, 'term_id'));
      if ($i >= 0) {
        $option        = $options[$i];
        $option->count = intval($term['term_count']);
        $_terms[]      = $option;
      }
    }

    $response->data['woostore_terms'] = $_terms;
    // $response->data['woostore_options'] = $options;

    return $response;
  }

  public function woostore_pro_woocommerce_rest_product_object_query($args, $request)
  {

    if (isset($request['taxonomy_query']) && $request['taxonomy_query']) {
      $tax_query = array();
      $taxonomy_query = json_decode($request['taxonomy_query'], true);
      foreach ($taxonomy_query as $attr) {
        $tax_query[] = array(
          'taxonomy' => $attr['taxonomy'],
          'field'    => $attr['field'],
          'terms'    => $attr['terms'],
        );
      }
      $args['tax_query'] = $tax_query;
    }

    return $args;
  }

  /**
   *
   * Get the terms and count
   *
   * @param $request
   * @param $taxonomy
   *
   * @return array|object|null
   */
  public function woostore_pro_terms($request, $taxonomy)
  {
    global $wpdb;

    $term_ids = wp_list_pluck(get_terms(array(
      'taxonomy'   => $taxonomy,
      'hide_empty' => true,
    )), 'term_id');

    $tax_query  = array();
    $meta_query = array();

    if (isset($request['attrs']) && $request['attrs']) {
      $attrs = json_decode($request['attrs'], true);
      foreach ($attrs as $attr) {
        $tax_query[] = array(
          'taxonomy' => $attr['taxonomy'],
          'field'    => $attr['field'],
          'terms'    => $attr['terms'],
        );
      }
    }

    $meta_query     = new \WP_Meta_Query($meta_query);
    $tax_query      = new \WP_Tax_Query($tax_query);
    $meta_query_sql = $meta_query->get_sql('post', $wpdb->posts, 'ID');
    $tax_query_sql  = $tax_query->get_sql($wpdb->posts, 'ID');

    // Generate query.
    $query           = array();
    $query['select'] = "SELECT COUNT( DISTINCT {$wpdb->posts}.ID ) as term_count, terms.term_id as term_count_id";
    $query['from']   = "FROM {$wpdb->posts}";
    $query['join']   = "
			INNER JOIN {$wpdb->term_relationships} AS term_relationships ON {$wpdb->posts}.ID = term_relationships.object_id
			INNER JOIN {$wpdb->term_taxonomy} AS term_taxonomy USING( term_taxonomy_id )
			INNER JOIN {$wpdb->terms} AS terms USING( term_id )
			" . $tax_query_sql['join'] . $meta_query_sql['join'];

    $query['where'] = "
			WHERE {$wpdb->posts}.post_type IN ( 'product' )
			AND {$wpdb->posts}.post_status = 'publish'"
      . $tax_query_sql['where'] . $meta_query_sql['where'] .
      'AND terms.term_id IN (' . implode(',', array_map('absint', $term_ids)) . ')';

    $query['group_by'] = 'GROUP BY terms.term_id';
    $query             = apply_filters('woocommerce_get_filtered_term_product_counts_query', $query);
    $query             = implode(' ', $query);

    return $wpdb->get_results($query, ARRAY_A);
  }

  /**
   *
   * Get min max price
   *
   * @param $request
   *
   * @return array|object|void|null
   */
  public function woostore_pro_get_min_max_prices($request)
  {
    global $wpdb;

    $tax_query = array();

    $params = $request->get_params();

    if (isset($params['categories']) && $params['categories']) {
      $categories = (array) json_decode($params['categories'], false);
      $tax_query[] = array(
        'relation' => 'AND',
        array(
          'taxonomy' => 'product_cat',
          'field'    => 'cat_id',
          'terms'    => $categories,
        ),
      );
    }

    $meta_query = array();

    $meta_query = new \WP_Meta_Query($meta_query);
    $tax_query  = new \WP_Tax_Query($tax_query);

    $meta_query_sql = $meta_query->get_sql('post', $wpdb->posts, 'ID');
    $tax_query_sql  = $tax_query->get_sql($wpdb->posts, 'ID');

    $sql = "SELECT min( min_price ) as min_price, MAX( max_price ) as max_price
			FROM {$wpdb->wc_product_meta_lookup}
			WHERE product_id IN (
				SELECT ID FROM {$wpdb->posts}
				" . $tax_query_sql['join'] . $meta_query_sql['join'] . "
				WHERE {$wpdb->posts}.post_type IN ('" . implode("','", array_map('esc_sql', apply_filters('woocommerce_price_filter_post_type', array('product')))) . "')
				AND {$wpdb->posts}.post_status = 'publish'
				" . $tax_query_sql['where'] . $meta_query_sql['where'] . '
			)';

    $sql = apply_filters('woocommerce_price_filter_sql', $sql, $meta_query_sql, $tax_query_sql);

    return $wpdb->get_row($sql); // WPCS: unprepared SQL ok.
  }
}
