try {
  document.getElementsByClassName("wp-toolbar")[0].removeAttribute("class");
  document.getElementById("adminmenumain").remove();
  document.getElementById("wpbody").remove();
  document.getElementById("wpfooter").remove();
  document.getElementById("wpadminbar").remove();
  document.getElementById("wpcontent").style.paddingLeft = 0;
  document.getElementById("wpcontent").style.marginLeft = 0;

  var div = document.createElement('div');
  div.setAttribute("id", "woostore-pro-api-render-stage");
  document.body.appendChild(div);
  var element = document.getElementById("woostore-pro-api-render-stage");
  if (typeof element !== "undefined" && element !== null) {
    element.innerHTML =
      '<div style="display: flex; height: 100vh; width: 100vw; align-items: center; justify-content: center">Loading</div>';
  }
} catch (e) {
  var div = document.createElement("div");
  div.setAttribute("id", "woostore-pro-api-render-stage");
  document.body.appendChild(div);
  var element = document.getElementById("woostore-pro-api-render-stage");
  if (typeof element !== "undefined" && element !== null) {
    element.innerHTML =
      '<div style="display: flex; height: 100vh; width: 100vw; align-items: center; justify-content: center">Loading</div>';
  }
}
