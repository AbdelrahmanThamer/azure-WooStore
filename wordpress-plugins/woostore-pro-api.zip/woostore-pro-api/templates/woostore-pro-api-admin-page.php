<?php include_once(plugin_dir_path(dirname(__FILE__)) . 'functions/index.php'); ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
  <style>
    h1 {
      font-size: 2rem;
    }

    h2 {
      font-size: 1.5rem;
      font-weight: 600;
    }

    hr {
      height: 3px;
      background: rgb(220, 220, 220);
      margin: 50px 0px;
    }

    p {
      width: 50vw;
      font-size: 16px;
      padding: 0;
      margin: 0;
    }

    .jwt-toggle {
      color: white;
      background-color: rgba(100, 100, 100, 1);
      cursor: pointer;
      margin-left: 10px;
      padding: 10px;
      border-radius: 6px;
    }

    .woostore_pro_input {
      margin-bottom: 10px;
      width: 50vw !important;
      padding: .857em 1.214em !important;
      background-color: rgb(245, 245, 245);
      color: black !important;
      font-size: 1.2em;
      font-weight: 500;
      border: #DDDDDD 2px solid;
      line-height: 1.286em !important;
      border-radius: 0.5em !important;
      box-sizing: border-box;
      box-shadow: inset 0 1px 2px rgba(0, 0, 0, .07) !important;
      transition: 300ms border-color ease-in-out;
      font-family: "Open Sans", HelveticaNeue-Light, "Helvetica Neue Light", "Helvetica Neue", Helvetica, Arial, "Lucida Grande", sans-serif;
      touch-action: manipulation;
    }

    .woostore_pro_button {
      position: relative;
      border: 0 none;
      border-radius: 3px !important;
      color: #fff !important;
      display: inline-block;
      font-family: 'Poppins', 'Open Sans', Helvetica, Arial, sans-serif;
      font-size: 12px;
      letter-spacing: 1px;
      line-height: 1.5;
      text-transform: uppercase;
      font-weight: 600;
      text-decoration: none;
      cursor: pointer;
      margin-right: 10px;
      line-height: 1;
      padding: 12px 30px;
      background: #39c36e !important;
      -webkit-transition: all 0.21s ease;
      -moz-transition: all 0.21s ease;
      -o-transition: all 0.21s ease;
      transition: all 0.21s ease;
    }

    .woostore_pro_title {
      font-size: 18px;
      font-weight: 500;
      margin-bottom: .5em;
      line-height: 1.1;
      display: block;
      margin-inline-start: 0px;
      margin-inline-end: 0px;
    }

    .woostore_pro_list {
      margin: 0;
      padding: 0;
      border: 0;
      font-size: 100%;
      font: inherit;
      display: block;
      margin-block-start: 1em;
      margin-block-end: 1em;
      margin-inline-start: 0px;
      margin-inline-end: 0px;
      padding-inline-start: 40px;
      list-style: none;
    }

    .woostore_pro_list li {
      list-style-type: square;
      font-size: 14px;
      font-weight: normal;
      margin-bottom: 6px;
      display: list-item;
      text-align: -webkit-match-parent;
    }

    .woostore_pro_number_list li {
      list-style-type: decimal;
    }

    .woostore_pro_link {
      margin-inline-start: 0px;
      margin-inline-end: 0px;
      color: #0099ff;
      text-decoration: none;
      outline: 0;
      transition-property: border, background, color;
      transition-duration: .05s;
      transition-timing-function: ease-in-out;
      margin: 0;
      padding: 0;
      border: 0;
      font-size: 100%;
      font: inherit;
      margin-bottom: 20px;
      display: block;
    }

    .woostore_pro_table {
      width: 100%;
      max-width: 100%;
      margin-bottom: 1.236rem;
      background-color: transparent;
      border-spacing: 0;
      border-collapse: collapse;
      display: table;
      border-color: grey;
    }

    .woostore_pro_table a {
      color: #0099ff;
      text-decoration: none;
    }

    .woostore_pro_table th,
    .woostore_pro_table td {
      text-align: left;
    }

    .woostore_pro_deactive_button {
      background: #C84B31 !important;
    }

    .woostore-pro-update-firebase-server-key {
      min-width: 50vw !important;
      color: black !important;
      font-size: 1.2em;
      font-weight: 500;
      border: #0099ff 2px solid;
      line-height: 1.286em !important;
      border-radius: 0.5em !important;
      box-sizing: border-box;
    }
  </style>
</head>

<body>
  <div class="wrap">
    <h1><strong>WooStore Pro API Settings</strong></h1>
    <div>
      <?php
      $verified = get_option("woostore_pro_purchase_code");
      if (isset($verified) && $verified == "1") {
      ?>
        <p style="font-size: 16px;color: green">Your website is active with the license and all the API features are unlocked.</p>
      <?php
      }
      ?>
    </div>
    <?php
    $verified = get_option("woostore_pro_purchase_code");
    if (!isset($verified) || $verified === "" || $verified === false) {
    ?>
      <form action="" enctype="multipart/form-data" method="post" style="margin-bottom:50px">
        <?php
        if (isset($_POST['but_verify'])) {
          $result = verifyPurchaseCode($_POST['code']);

          if ($result !== true) {
        ?>
            <p style="font-size: 16px;color: red;"><?= $result ?></p>
          <?php
          } else {
          ?>
            <p style="font-size: 16px;color: green">Your website is active with the license and all the API features are unlocked.</p>
        <?php
            header("Refresh:0");
          }
        }
        ?>
        <div class="form-group" style="margin-top:10px; margin-bottom:20px;">
          <p>Please verify your purchase code. It is required to acivate the WooStore Pro Api Plugin before you can use the application. The application will not work if the purchase code is not verified.</p>
          <br>
          <input name="code" placeholder="Purchase Code" type="text" class="woostore_pro_input">
        </div>
        <div>
          <h4 class="woostore_pro_title">What is purchase code?</h4>
          <ul class="woostore_pro_list">
            <li>A purchase code is a license identifier which is issued with the item once a purchase has been made and included with your download.</li>
            <li>One purchase code is used for one website only.</li>
            <li>It's required to activate and unlock the API used to connect with the app.</li>
          </ul>
          <h4 class="woostore_pro_title">How can I get my purchase code? </h4>
          <ul class="woostore_pro_list woostore_pro_number_list">
            <li>Log into your Envato Market account.</li>
            <li>Hover the mouse over your username at the top of the screen.</li>
            <li>Click ‘Downloads’ from the drop-down menu.`</li>
            <li>Click ‘License certificate & purchase code’ (available as PDF or text file).</li>
          </ul>
          <a class="woostore_pro_link" href="https://help.market.envato.com/hc/en-us/articles/202822600-Where-Is-My-Purchase-Code-">https://help.market.envato.com/hc/en-us/articles/202822600-Where-Is-My-Purchase-Code-</a>
        </div>
        <button type="submit" class="woostore_pro_button" name='but_verify'>Verify</button>
      </form>
    <?php
    }
    if (isset($verified) && $verified === '1') {
    ?>
      <hr>
      <h2><strong>JWT Secret Key</strong></h2>
      <p>
        Enter the Json Web Token secret key here. It is required to use the API with the application.
        <br>
        You can use a string from here <a href="https://api.wordpress.org/secret-key/1.1/salt/" target="_blank" rel="noopener noreferrer">https://api.wordpress.org/secret-key/1.1/salt/</a>
      </p>
      <form action="" method="post">
        <?php

        if (isset($_POST['save_jwt_secret'])) {
          if (isset($_POST['jwt_key']) && !empty($_POST['jwt_key'])) {
            // the key is not null and button is pressed, go ahead and save the key
            $result = woostore_pro_save_secret_jwt_key($_POST['jwt_key']);
            if ($result === true) {
        ?>
              <span style="color: green;">Your JWT key was saved</span>
            <?php
            } else {
            ?>
              <span style="color: red;">Could not update the key!</span>
            <?php
            }
          } else {
            ?>
            <span style="color: red;">Please enter a valid and strong jwt key</span>
        <?php
          }
        }
        $secretKey = get_option("woostore_pro_api_secret_jwt_key");
        ?>
        <div class="form-group" style="margin-top:30px;margin-bottom:20px">
          <input type="password" placeholder="Enter JWT Secret key" value="<?= $secretKey ?>" name="jwt_key" class="woostore-pro-jwt-key woostore_pro_input jwt-input-field">
          <span class="jwt-toggle">Show</span>
        </div>
        <button type="submit" class="woostore_pro_button" name='save_jwt_secret'>Save JWT Key</button>
      </form>
      <hr>
      <h2><strong>Firebase Settings</strong></h2>
      <p>
        The server key for firebase which is used to push notification when the order status changes.
        <br><br>
        Find you key from the below path: <br>
        <span style="font-size: 14px; font-weight: 600;">Firebase project -> Project Settings -> Cloud Messaging -> Server key</span>
      </p>
      <form action="" method="post">
        <?php $serverKey = get_option("woostore_pro_firebase_server_key"); ?>
        <div class="form-group" style="margin-top:30px;margin-bottom:20px">
          <input type="password" placeholder="Enter Firebase server key" value="<?= $serverKey ?>" name="firebase_server_key" class="woostore-pro-update-firebase-server-key woostore_pro_input">
        </div>
        <span style="font-size: 14px; color: red;">Please note that if the the server key is empty then NO notification will be sent.</span>
      </form>
      <hr>
      <h2><strong>Order Status Changed Notification Message</strong></h2>
      <p>This is the template of the message which will be sent to the users each time their order status changes.</p>
      <form action="" method="post">
        <?php
        $statusOrderTitle = get_option("woostore_pro_status_order_title");
        if (!isset($statusOrderTitle) || $statusOrderTitle == false) {
          $statusOrderTitle = "Order Status Changed";
        }
        $statusOrderMsg = get_option("woostore_pro_status_order_message");
        if (!isset($statusOrderMsg) || $statusOrderMsg == false) {
          $statusOrderMsg = "Hi {{name}}, Your order: #{{orderId}} changed from {{prevStatus}} to {{nextStatus}}";
        }
        ?>
        <div style="height: 20px;"></div>
        <label>Title</label>
        <div class="form-group" style="margin-top:10px;">
          <input type="text" placeholder="Title" value="<?= $statusOrderTitle ?>" class="woostore-pro-update-status-order-title woostore_pro_input">
        </div>
        <div style="height: 10px;"></div>
        <label>Notification Message</label>
        <div class="form-group" style="margin-top:10px;margin-bottom:40px">
          <textarea placeholder="Message" class="woostore-pro-update-status-order-message woostore_pro_input" style="height: 120px"><?= $statusOrderMsg ?></textarea>
        </div>
      </form>
      <hr>
      <form action="" enctype="multipart/form-data" method="post" style="margin-bottom:50px">
        <?php
        if (isset($_POST['but_deactive'])) {
          $result = deactivatePurchaseCode();
          if ($result !== true) {
        ?>
            <p style="font-size: 16px;color: red;"><?= $result ?></p>
        <?php
          } else {
            header("Refresh:0");
          }
        }
        ?>
        <button type="submit" class="woostore_pro_button woostore_pro_deactive_button" name='but_deactive' onclick="return confirm('Are you sure to deactivate the license for this domain?');">Deactivate License</button>
      </form>
      <div style="height: 10vh;"></div>
    <?php
    }
    ?>
  </div>
</body>

</html>