<?php

namespace WooStoreProApi\Functions;

function pushNotification ($title, $message, $deviceToken) {
    $serverKey = get_option("woostore_pro_firebase_server_key");
    if (isset($serverKey) && $serverKey != false) {
        $body = ["notification" => ["title" => $title, "body" => $message, "click_action" => "FLUTTER_NOTIFICATION_CLICK"], "data" => ["title" => $title, "body" => $message, "click_action" => "FLUTTER_NOTIFICATION_CLICK"], "to" => $deviceToken];
        $headers = ["Authorization" => "key=".$serverKey, 'Content-Type' => 'application/json; charset=utf-8'];
        $response = wp_remote_post("https://fcm.googleapis.com/fcm/send", ["headers" => $headers, "body" => json_encode($body)]);
        $statusCode = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        return $statusCode == 200;
    }
    return false;
}

function sendNotificationToUser($userId, $orderId, $previous_status, $next_status){
    $user = get_userdata($userId);
    // $deviceToken = get_option("woostore_pro_device_token_".$userId);
    $deviceToken = get_user_meta($userId,"woostore_pro_device_token", true);

    if(empty($deviceToken) || $deviceToken == false){
        $deviceToken = get_option("woostore_pro_device_token_".$userId);
    }

    if (isset($deviceToken) && $deviceToken != false) {
        $itle = get_option("woostore_pro_status_order_title");
        if (!isset($itle) || $itle == false) {
            $itle = "Order Status Changed";
        }
        $message = get_option("woostore_pro_status_order_message");
        if (!isset($message) || $message == false) {
            $message = "Hi {{name}}, Your order: #{{orderId}} changed from {{prevStatus}} to {{nextStatus}}";
        }
        $message = str_replace("{{name}}", $user->display_name, $message);
        $message = str_replace("{{orderId}}", $orderId, $message);
        $message = str_replace("{{prevStatus}}",$previous_status, $message);
        $message = str_replace("{{nextStatus}}",$next_status, $message);
        pushNotification($itle, $message, $deviceToken);
    }
}

function trackOrderStatusChanged($id, $previous_status, $next_status){
    $order = wc_get_order( $id );
    $userId = $order->get_customer_id();
    sendNotificationToUser($userId, $id, $previous_status, $next_status);
}

function sendNewOrderNotificationToVendor($order_seller_id){
    $user = get_userdata($order_seller_id);
    // $deviceToken = get_option("woostore_pro_device_token_".$order_seller_id);
    $deviceToken = get_user_meta($order_seller_id, "woostore_pro_device_token", true);

    if (empty($deviceToken) || $deviceToken == false) {
        $deviceToken = get_option("woostore_pro_device_token_" . $order_seller_id);
    }

    if (isset($deviceToken) && $deviceToken != false) {
        $title = get_option("woostore_pro_new_order_title");
        if (!isset($title) || $title == false) {
            $title = "New Order";
        }
        $message = get_option("woostore_pro_new_order_message");
        if(!isset($message) || $message == false){
            $message = "Hi {{name}}, Congratulations, you have received a new order! ";
        }
        $message = str_replace("{{name}}", $user->display_name, $message);
        pushNotification($title, $message, $deviceToken);
    }
}

function woostore_pro_save_secret_jwt_key($jwt_key){
    if(empty($jwt_key)){
        return false;
    }
    // Update the option
    return update_option('woostore_pro_api_secret_jwt_key', $jwt_key);
}
