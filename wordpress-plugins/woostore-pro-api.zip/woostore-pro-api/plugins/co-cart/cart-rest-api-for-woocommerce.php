<?php

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'COCART_FILE' ) ) {
	define( 'COCART_FILE', __FILE__ );
}

// Include the main CoCart class.
if ( ! class_exists( 'CoCart', false ) ) {
	include_once untrailingslashit( plugin_dir_path( COCART_FILE ) ) . '/includes/class-cocart.php';
}

/**
 * Returns the main instance of CoCart and only runs if it does not already exists.
 *
 * @since   2.1.0
 * @version 2.6.0
 * @return CoCart
 */
if ( ! function_exists( 'CoCart' ) ) {
	function CoCart() {
		return CoCart::init();
	}

	CoCart();

	/**
	 * Load backend features only if COCART_WHITE_LABEL constant is
	 * NOT set or IS set to false in user's wp-config.php file.
	 */
	if (
		! defined( 'COCART_WHITE_LABEL' ) || false === COCART_WHITE_LABEL &&
		is_admin() || ( defined( 'WP_CLI' ) && WP_CLI )
	) {
		include_once untrailingslashit( plugin_dir_path( COCART_FILE ) ) . '/includes/admin/class-cocart-admin.php';
	}
}
