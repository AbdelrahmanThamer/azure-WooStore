<?php

// Copyright (c) 2022 Aniket Malik [aniketmalikwork@gmail.com] 
// All Rights Reserved.
// 
// NOTICE: All information contained herein is, and remains the
// property of Aniket Malik. The intellectual and technical concepts
// contained herein are proprietary to Aniket Malik and are protected
// by trade secret or copyright law.
// 
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// Aniket Malik.

use WOOSTORE_PRO_API\JWT\ExpiredException;
use WOOSTORE_PRO_API\JWT\JWT;
use WooStoreProApi\Api\Base;

class AuthUtils
{
  /**
   * @param string $jwt
   * @return int|WP_Error $user_id or null if no user is found
   */
  static public function validateJWT($jwt)
  {
    try {
      $secret_key = get_option('woostore_pro_api_secret_jwt_key');

      /** First thing, check the secret key if not exist return a error*/
      if (!$secret_key || empty($secret_key)) {
        return Base::sendError(
          'jwt_auth_bad_config',
          'JWT is not configurated properly, please contact the admin',
          403
        );
      }
      // This is the data payload
      $d = JWT::decode($jwt, $secret_key, array('HS256'));
      $user_id = $d->data->user->id;

      if (empty($user_id)) {
        return Base::sendError('invalid_token', 'Could not find the user', 404);
      }

      return $user_id;
    } catch (ExpiredException $e){
      return Base::sendError('expired_token', 'You auth token has expired. Please login again.', 401);
    }catch (\Throwable $th) {
      return Base::sendError('jwt_auth_error', $th->getMessage(), 500);
    }
  }
}
