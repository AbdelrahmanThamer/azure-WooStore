<?php
// Copyright (c) 2022 Aniket Malik [aniketmalikwork@gmail.com] 
// All Rights Reserved.
// 
// NOTICE: All information contained herein is, and remains the
// property of Aniket Malik. The intellectual and technical concepts
// contained herein are proprietary to Aniket Malik and are protected
// by trade secret or copyright law.
// 
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// Aniket Malik.

namespace WooStoreProApi\Api;

use WC_Customer;
use WP_Error;
use WC_Cart;
use WP_REST_Response;

defined('ABSPATH') or wp_die('No scripts!');

abstract class CartUtils
{

  /**
   * Prepare the cart items for the customer
   * @param array cart contents
   * @return array
   */
  static public function prepare_cart_items_for_response($cart_items)
  {

    if (null === $cart_items || is_wp_error($cart_items)) {
      return [];
    }

    // Get cart$cart_items items array
    $cart_items = maybe_unserialize($cart_items);
    if (!is_array($cart_items)) {
      return [];
    }
    $items = [];

    // Loop through cart items and get cart items details
    $product_controller = new \WC_REST_Products_Controller();
    $product_variation_controller = new \WC_REST_Product_Variations_Controller();
    foreach ($cart_items as $cart_item_key => $cart_item) {
      $product_id = $cart_item['product_id'];
      $variation_id = $cart_item['variation_id'];
      $quantity = $cart_item['quantity'];

      $product = wc_get_product($product_id);
      $product_data = $product_controller->prepare_object_for_response($product, null)->get_data();

      if ($variation_id != 0) {
        $variation = new \WC_Product_Variation($variation_id);
        $variation_data = $product_variation_controller->prepare_object_for_response($variation, null)->get_data();
      } else {
        $variation_data = null;
      }
      $items[] = array(
        "cart_item_key" => $cart_item_key,
        "quantity" => $quantity,
        "variation" => $variation_data,
        "addons" => isset($cart_item['addons']) ? $cart_item['addons'] : [],
        "product" => $product_data
      );
    }

    return $items;
  }

  /**
   * 
   */
  static public function prepare_single_cart_item_for_response($cart_item_key, $product_id, $variation_id = 0, $quantity, $cart_item_data)
  {
    // Loop through cart items and get cart items details
    $product_controller = new \WC_REST_Products_Controller();
    $product_variation_controller = new \WC_REST_Product_Variations_Controller();
    $product = wc_get_product($product_id);
    $product_data = $product_controller->prepare_object_for_response($product, null)->get_data();

    if (!empty($variation_id) && $variation_id != 0) {
      $variation = new \WC_Product_Variation($variation_id);
      $variation_data = $product_variation_controller->prepare_object_for_response($variation, null)->get_data();
    } else {
      $variation_data = null;
    }
    return array(
      "cart_item_key" => $cart_item_key,
      "quantity" => $quantity,
      "addons" => isset($cart_item_data['addons']) ? $cart_item_data['addons'] : [],
      "product" => $product_data,
      "variation" => $variation_data
    );
  
  }

  /**
   * Get the cart content for the user
   * @param int $customer_id
   * @return WC_Cart
   */
  static public function get_customer_cart($customer_id)
  {
    WC()->frontend_includes();
    wc_load_cart();
    $user = get_userdata($customer_id);
    wp_set_current_user($customer_id, $user->user_login);
    wp_set_auth_cookie($customer_id);
    WC()->customer = new WC_Customer($customer_id, true);
    WC()->cart->get_cart();
    return WC()->cart;
  }

  /**
   * @param array $params The request parameters
   * @return \WC_Cart
   */
  static public function create_cart_with_details($params)
  {
    try {
      $coupon_code = (string) $params['coupon_code'];
      $line_items = (array) $params['line_items'];

      if (isset($params['customer_id'])) {
        $customer_id = (int) $params['customer_id'];
      } else {
        $customer_id = 0;
      }

      if (defined('WC_ABSPATH')) {
        // WC 3.6+ - Cart and other frontend functions are not included for REST requests.
        include_once WC_ABSPATH . 'includes/wc-cart-functions.php';
        include_once WC_ABSPATH . 'includes/wc-notice-functions.php';
        include_once WC_ABSPATH . 'includes/wc-template-hooks.php';
      }

      WC()->frontend_includes();
      if (null === WC()->session) {
        $session_class = apply_filters('woocommerce_session_handler', 'WC_Session_Handler');

        WC()->session = new $session_class();
        WC()->session->init();
      }

      if (null === WC()->customer) {
        WC()->customer = new WC_Customer($customer_id, false);
      }

      if (null === WC()->cart) {
        WC()->cart = new WC_Cart();
        WC()->cart->get_cart();
      }

      WC()->cart->empty_cart(true);

      $billing = $params["billing"];
      if (!empty($billing)) {
        WC()->customer->set_billing_first_name($billing["first_name"]);
        WC()->customer->set_billing_last_name($billing["last_name"]);
        WC()->customer->set_shipping_first_name($billing["first_name"]);
        WC()->customer->set_shipping_last_name($billing["last_name"]);
        WC()->customer->set_billing_company($billing["company"]);
        WC()->customer->set_billing_address_1($billing["address_1"]);
        WC()->customer->set_billing_address_2($billing["address_2"]);
        WC()->customer->set_billing_city($billing["city"]);
        WC()->customer->set_billing_state($billing["state"]);
        WC()->customer->set_billing_postcode($billing["postcode"]);
        WC()->customer->set_billing_country($billing["country"]);
      }

      $shipping = $params["shipping"];
      if (!empty($shipping)) {
        WC()->customer->set_shipping_company($shipping["company"]);
        WC()->customer->set_shipping_address_1($shipping["address_1"]);
        WC()->customer->set_shipping_address_2($shipping["address_2"]);
        WC()->customer->set_shipping_city($shipping["city"]);
        WC()->customer->set_shipping_state($shipping["state"]);
        WC()->customer->set_shipping_postcode($shipping["postcode"]);
        WC()->customer->set_shipping_country($shipping["country"]);
      }

      $cart = WC()->cart;
      $count = 1;
      while ($count <= 2) {
        $count++;
        $cart->empty_cart();
        foreach ($line_items as $line_item) {
          $cart->add_to_cart(
            $line_item['product_id'],
            $line_item['quantity'],
            isset($line_item['variation_id']) ? $line_item['variation_id'] : 0,
            isset($line_item['variation']) ? $line_item['variation'] : array(),
            isset($line_item['cart_item_data']) ? $line_item['cart_item_data'] : array(),
          );
        }
        WC()->session->set('chosen_shipping_methods', array($params['shipping_line']['method_id'] . ':' . $params['shipping_line']['instance_id']));
      }

      if (!empty($coupon_code)) {
        WC()->cart->apply_coupon($coupon_code);
      }

      return $cart;
    } catch (\Throwable $th) {
      return Base::sendError('WooStore Pro Api create_cart_with_details', $th->getMessage(), 400);
    }
  }

  /**
   * @param \WC_Cart $cart The cart to use to create the return response
   * @param array $other
   * @return \WP_REST_Response|WP_Error 
   */
  static public function prepare_cart_for_response($cart, $other = array())
  {
    if ($cart === null) {
      return Base::sendError('not_found', 'The cart for the customer could not be found!', 404);
    }

    if (is_wp_error($cart)) {
      /** @var WP_Error */
      $e = $cart;
      return Base::sendError($e->get_error_code(), $e->get_error_message(), 404);
    }

    return new WP_REST_Response(
      array_merge(array(
        "totals" => $cart->get_totals(),
        "line_items" => CartUtils::prepare_cart_items_for_response($cart->cart_contents),
      ), $other)
    );
  }

  /**
   * Check any prerequisites for our REST request.
   */
  static public function check_prerequisites()
  {
    if (defined('WC_ABSPATH')) {
      // WC 3.6+ - Cart and other frontend functions are not included for REST requests.
      include_once WC_ABSPATH . 'includes/wc-cart-functions.php';
      include_once WC_ABSPATH . 'includes/wc-notice-functions.php';
      include_once WC_ABSPATH . 'includes/wc-template-hooks.php';
    }

    WC()->frontend_includes();

    if (null === WC()->session) {
      $session_class = apply_filters('woocommerce_session_handler', 'WC_Session_Handler');

      WC()->session = new $session_class();
      WC()->session->init();
    }

    if (null === WC()->customer) {
      WC()->customer = new WC_Customer(get_current_user_id(), true);
    }

    if (null === WC()->cart) {
      WC()->cart = new WC_Cart();

      WC()->cart->get_cart();
    }
  }

  /**
   * @param string $session_customer_id
   * @return \WC_Cart
   */
  static public function load_cart_from_session_id($session_customer_id)
  {
    try {
      $session_data = WC()->session->get_session($session_customer_id);
      $cart = new WC_Cart();
      $cart->set_cart_contents(maybe_unserialize($session_data['cart']));
      $cart->set_totals(maybe_unserialize($session_data['cart_totals']));
      $cart->set_applied_coupons(maybe_unserialize($session_data['applied_coupons']));
      $cart->set_coupon_discount_totals(maybe_unserialize($session_data['coupon_discount_totals']));
      $cart->set_coupon_discount_tax_totals(maybe_unserialize($session_data['coupon_discount_tax_totals']));
      $cart->set_removed_cart_contents(maybe_unserialize($session_data['removed_cart_contents']));
      return $cart;
    } catch (\Throwable $th) {
      return Base::sendError('WooStore Pro Api load_cart_from_session_id error', $th->getMessage(), 500);
    }
  }
}
