<?php

namespace WooStoreProApi;

/**
 * Class Utils
 * @author ngocdt@rnlab.io
 * @since 1.0.0
 */
class Utils {

	/**
	 * Returns true if we are making a REST API request for App builder.
	 *
	 * @return  bool
	 */
	public static function is_rest_api_request() {
		if ( empty( $_SERVER['REQUEST_URI'] ) ) {
			return false;
		}

		$rest_prefix = trailingslashit( rest_get_url_prefix() );
		$uri         = $_SERVER['REQUEST_URI'];
		$allows      = array( 'wc/store/cart' );

		foreach ( $allows as $allow ) {
			$check = strpos( $uri, $rest_prefix . $allow ) !== false;
			if ( $check ) {
				return true;
			}
		}

		return false;
	}
	
	/**
	 * Convert mysql datetime to PHP timestamp, forcing UTC. Wrapper for strtotime.
	 *
	 * Based on wcs_strtotime_dark_knight() from WC Subscriptions by Prospress.
	 *
	 * @param string $time_string Time string.
	 * @param int|null $from_timestamp Timestamp to convert from.
	 *
	 * @return int
	 * @since  1.0.0
	 */
	public static function string_to_timestamp( $time_string, $from_timestamp = null ) {
		$original_timezone = date_default_timezone_get();

		// @codingStandardsIgnoreStart
		date_default_timezone_set( 'UTC' );

		if ( null === $from_timestamp ) {
			$next_timestamp = strtotime( $time_string );
		} else {
			$next_timestamp = strtotime( $time_string, $from_timestamp );
		}

		date_default_timezone_set( $original_timezone );

		// @codingStandardsIgnoreEnd

		return $next_timestamp;
	}

	/**
	 *
	 * Check vendor plugin active
	 *
	 * @return string
	 * @since 1.0.11
	 */
	public static function vendorActive(): string {
		if ( class_exists( 'WeDevs_Dokan' ) || class_exists( 'Dokan_Pro' ) ) {
			return 'dokan';
		}

		if ( class_exists( 'WCFMmp' ) ) {
			return 'wcfm';
		}

		if ( class_exists( 'WCMp' ) ) {
			return 'wcmp';
		}

		if ( class_exists( 'WC_Product_Vendors' ) ) {
			return 'wc_pv';
		}

		if ( class_exists( 'WooCommerce' ) ) {
			return 'single';
		}

		return 'blog';
	}
}
