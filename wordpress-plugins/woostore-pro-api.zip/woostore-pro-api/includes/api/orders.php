<?php
// Copyright (c) 2021 Aniket Malik [aniketmalikwork@gmail.com] 
// All Rights Reserved.
// 
// NOTICE: All information contained herein is, and remains the
// property of Aniket Malik. The intellectual and technical concepts
// contained herein are proprietary to Aniket Malik and are protected
// by trade secret or copyright law.
// 
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// Aniket Malik.

namespace WooStoreProApi\Api;

defined('ABSPATH') or wp_die('No scripts!');


require_once(__DIR__ . '/base.php');

use Automattic\WooCommerce\Admin\Overrides\Order;
use WC_Order;
use WP_REST_Server;
use WooStoreProApi\Api\Base;
use WP_REST_Response;
use WP_REST_Request;
use WC_REST_Orders_Controller;
use WP_Error;

class WooStoreProOrdersController extends WC_REST_Orders_Controller{

  public function __construct(){
    $this->namespace = 'woostore_pro_api/order';
  }

  public function register_routes(){
    register_rest_route($this->namespace, '/create', array(
      array(
        'methods'   => WP_REST_Server::CREATABLE,
        'callback'  => array($this, 'create_order'),
        'permission_callback' => function () {
          return Base::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/update', array(
      array(
        'methods'   => WP_REST_Server::CREATABLE,
        'callback'  => array($this, 'update_order'),
        'permission_callback' => function () {
          return Base::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/delete', array(
      array(
        'methods'   => WP_REST_Server::DELETABLE,
        'callback'  => array($this, 'delete_order'),
        'permission_callback' => function () {
          return Base::checkApiPermission();
        }
      ),
    ));
  }

  /**
   * @param WP_REST_Request $request
   * @return WP_REST_Response
   */
  public function create_order($request)
  {
    try {
      include_once WOOSTORE_PRO_API_PATH . '/includes/cart_utils.php';
      $params = $request->get_params();
      CartUtils::create_cart_with_details($params);
      $order = $this->create_order_helper($params);
      $order->save();
      $orc = new WC_REST_Orders_Controller();
      $data = $orc->prepare_object_for_response($order, null)->data;
      return $data;
    } catch (\Throwable $th) {
      return Base::sendError('WooStore Pro Api create order error', $th->getMessage(), 400);
    }
  }

  /**
   * @param WP_REST_Request $request
   * @return WP_REST_Response
   */
  public function update_order($request)
  {

    $params = $request->get_params();
    $order_id = $params['id'];

    $order = wc_get_order($order_id);

    if(is_bool($order)){
      return new WP_Error('Order is not valid');
    }

    if($order instanceof WC_Order){
      $order->remove_order_items();
      return $this->update_item($request);
    }

    return new WP_Error('Order is not valid');
  }

  /**
   * @param WP_REST_Request $request
   * @return WP_REST_Response
   */
  public function delete_order($request)
  {

    $params = $request->get_params();
    $order_id = $params['id'];

    $order = wc_get_order($order_id);

    if (is_bool($order)) {
      return new WP_Error('Order is not valid');
    }

    if ($order instanceof WC_Order) {
      return $order->delete(true);
    }

    return new WP_Error('Order is not valid');
  }

  /**
   * @param array $data 
   * @return Order order
   */
  public static function create_order_helper($data)
  {
    try {

      $order = new Order();
      $order->set_created_via('woostore-pro-api-checkout');
      $order->set_cart_hash(WC()->cart->get_cart_hash());
      $order->set_customer_id(isset($data['customer_id']) ? $data['customer_id'] : 0);
      $order->set_currency(get_woocommerce_currency());
      $order->set_prices_include_tax('yes' === get_option('woocommerce_prices_include_tax'));
      $order->set_customer_note(isset($data['customer_note']) ? $data['customer_note'] : '');
      $order->set_address(isset($data['billing']) ? $data['billing'] : array());
      $order->set_address(isset($data['shipping']) ? $data['shipping'] : array(), 'shipping');
      $order->set_payment_method(isset($data['payment_method']) ? $data['payment_method'] : '');
      $order->set_payment_method_title(isset($data['payment_method_title']) ? $data['payment_method_title'] : '');
      $order->set_meta_data(isset($data['meta_data']) ? $data['meta_data'] : array());

      // Use the checkout functions
      $checkout = WC()->checkout();
      $checkout->set_data_from_cart($order);
      return $order;
    } catch (\Throwable $e) {
      return new WP_Error('WooStore Pro Api - Review Order', $e->getMessage());
    }
  }
}