<?php
// Copyright (c) 2022 Aniket Malik [aniketmalikwork@gmail.com] 
// All Rights Reserved.
// 
// NOTICE: All information contained herein is, and remains the
// property of Aniket Malik. The intellectual and technical concepts
// contained herein are proprietary to Aniket Malik and are protected
// by trade secret or copyright law.
// 
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// Aniket Malik.

namespace WooStoreProApi\Api;

defined('ABSPATH') || exit;

require_once(__DIR__ . '/base.php');

use WP_REST_Posts_Controller;
use WP_REST_Request;

class WooStoreProPostsController extends WP_REST_Posts_Controller
{

	public function __construct()
	{
		$this->namespace = 'woostore_pro_api';
	}

	public function register_routes()
	{
		register_rest_route($this->namespace, '/posts', array(
			'methods'             => \WP_REST_Server::READABLE,
			'args'							=> $this->get_collection_params(),
			'callback'            => array($this, '_get_posts'),
			'permission_callback' => function () {
				return Base::checkApiPermission();
			}
		));

		register_rest_route($this->namespace, '/posts/(?P<id>[\d]+)', array(
			'args'        => array(
				'id' => array(
					'description' => __('Unique identifier for the post.'),
					'type'        => 'integer',
				),
			),
			'methods'             => \WP_REST_Server::READABLE,
			// 'args'							=> $this->get_collection_params(),
			'callback'            => array($this, '_get_single_post'),
			'permission_callback' => function () {
				// return Base::checkApiPermission();
				return true;
			}
		));
	}

	/**
	 * @param WP_REST_Request $request - The parameters for the posts request
	 */
	public function _get_posts($request)
	{
		try {
			$response = $this->get_items($request);
			if (is_wp_error($response)) {
				return $response;
			}
			$raw_responses = $response->get_data();
			$result_posts = [];
			foreach ($raw_responses as $raw_post_response) {
				$result_posts[] = $this->rest_prepare_post($raw_post_response);
			}
			return new \WP_REST_Response($result_posts);
		} catch (\Throwable $th) {
			return Base::sendError('internal_error', $th->getMessage(), 500);
		}
	}

	/**
	 * @param WP_REST_Request $request - The parameters for the posts request
	 */
	public function _get_single_post($request)
	{
		try {
			$id = (int) $request['id'];
			if (empty($id)) {
				return Base::sendError('invalid_param', 'The parameter "id" cannot be empty', 400);
			}
			$result_post = $this->rest_prepare_post(['id' => $id]);
			if (null === $result_post['content'] || empty($result_post['content']) || null === $result_post['title'] || empty($result_post['title']) || null === $result_post['id'] || empty($result_post['id'])) {
				return Base::sendError('not_found', 'The post cannot be found', 404);
			}
			return new \WP_REST_Response($result_post);
		} catch (\Throwable $th) {
			return Base::sendError('internal_error', $th->getMessage(), 500);
		}
	}

	/**
	 *
	 * Pre post response
	 *
	 * @param $terms
	 *
	 * @return array
	 */
	public function prepare_tax_response($terms): array
	{
		return array_map(function ($item) {

			$data = array();

			$data['id']          = (int) $item->term_id;
			$data['count']       = (int) $item->count;
			$data['description'] = $item->description;
			$data['name']        = $item->name;
			$data['slug']        = $item->slug;
			$data['parent']      = (int) $item->parent;

			return $data;
		}, $terms);
	}

	public function rest_prepare_post($post_response)
	{
		$post = get_post($post_response['id']);
		$woostore_pro_rest_object = array(
			"id" => $post->ID,
			"date" => $post->post_date,
			"title" => htmlspecialchars_decode($post->post_title),
			"slug" => $post->post_name,
			"link" => get_post_permalink($post),
			"content" => $post->post_content,
			"display_image" => get_the_post_thumbnail_url($post),
			"author" => get_the_author_meta('display_name', $post->post_author),
			"type" => $post->post_type,
		);
		$tags       = get_the_tags($post->ID);
		$categories = get_the_category($post->ID);

		// Category
		$woostore_pro_rest_object['categories'] = $categories ? $this->prepare_tax_response($categories) : array();

		// Tags
		$woostore_pro_rest_object['tags'] = $tags ? $this->prepare_tax_response($tags) : array();

		// Count comment
		$woostore_pro_rest_object['comment_count'] = (int) get_comments_number($post);

		return $woostore_pro_rest_object;
	}
}
