<?php
namespace WooStoreProApi\Api;

defined('ABSPATH') or wp_die('No scripts!');

class Base
{

  /**
   * @return bool
   */
  public function admin_permissions_check()
  {
    return current_user_can('manage_options');
  }

  /**
   * @return array
   */
  static public function prepare_settings_data(): array{
    $result = array();
    $purchase_code = get_option('woostore_pro_purchase_code_key');
    $jwt_secret_key = get_option('woostore_pro_api_secret_jwt_key');
    $firebase_server_key = get_option('woostore_pro_firebase_server_key');
    $order_title = get_option('woostore_pro_status_order_title');
    $order_message = get_option('woostore_pro_status_order_message');
    $result['website'] = site_url();
    $result['admin_email'] = get_option('admin_email');
    $result['rest_api_url'] = rest_url();
    $result['wp_nonce'] = wp_create_nonce('wp_rest');
    $result['extra_data'] = array(
      'version' => WOOSTORE_PRO_API_VERSION,
    );
    $result['purchase_code'] = $purchase_code;
    $result['jwt_secret_key'] = $jwt_secret_key;
    $result['firebase_server_api_key'] = $firebase_server_key;
    $result['order_notification_title'] = $order_title;
    $result['order_notification_message'] = $order_message;
    return $result;
  }

  /**
   * Check permissions for the posts.
   *
   * @param WP_REST_Request $request Current request.
   */
  static public function sendError($code, $message, $statusCode)
  {
    return new \WP_Error($code, $message, array('status' => $statusCode));
  }

  static public function checkApiPermission()
  {
    $code = get_option('woostore_pro_purchase_code_key');
    if ($code !== null && $code !== false && strlen($code) >= 10) {
      return true;
    } else {
      return Base::sendError('invalid_license', 'The application has not been activated with a valid license, please contact the admin to activate the application', 403);
    }
  }

  /**
   * @param String $version
   * @param String $route
   * @return String namespace
   */
  static public function createNameSpace($version, $route)
  {
    return WOOSTORE_PRO_API_REST_BASE . '/' . $version . '/' . $route;
  }
}
