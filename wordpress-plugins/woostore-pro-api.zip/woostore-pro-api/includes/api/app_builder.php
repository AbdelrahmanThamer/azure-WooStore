<?php

namespace WooStoreProApi\Api;

defined('ABSPATH') or wp_die('No scripts!');

require_once(__DIR__ . '/base.php');

use WP_REST_Server;
use WooStoreProApi\Api\Base;
use WP_Error;
use WP_REST_Response;

class WooStoreProAppBuilder extends Base
{

  public $app_template_option_key = 'woostore_pro_app_template';

  public function __construct()
  {
    $this->namespace = 'woostore_pro_api/app_builder';
  }


  public function register_routes()
  {

    register_rest_route($this->namespace, '/app_template', array(
      array(
        'methods'   => WP_REST_Server::CREATABLE,
        'callback'  => array($this, 'upload_app_template'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
      array(
        'methods'   => WP_REST_Server::READABLE,
        'callback'  => array($this, 'get_app_template'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        },
      ),
    ));
  }

  /**
   * @param \WP_REST_Request $request
   */
  public function get_app_template($request)
  {
    try {
      $app_template_data = get_option($this->app_template_option_key);

      if (false === $app_template_data) {
        return Base::sendError('no_template_found', 'There was no template available on the website', 404);
      }

      return new WP_REST_Response($app_template_data, 200, ['cache-control' => 'public']);
    } catch (\Throwable $th) {
      return Base::sendError('internal_error', $th->getMessage(), 500);
    }
  }

  /**
   * @param \WP_REST_Request $request
   */
  public function upload_app_template($request)
  {
    try {

      $params = $request->get_params();

      $email = $params['email'];
      $password = $params['password'];

      if (empty($email) || empty($password)) {
        return Base::sendError('invalid_credentials', 'Required credentials are missing', 400);
      }

      $user = wp_authenticate($email, $password);
      if(is_wp_error($user)){
        return Base::sendError('auth_failed', wp_strip_all_tags($user->get_error_message()), 400);
      }

      wp_set_current_user($user->ID);
      $permisson = current_user_can('manage_options');

      if(false === $permisson){
        return Base::sendError('forbidden', 'This user does not have the permission to perform this action', 400);
      }

      // App Template data
      $app_template_data = $params['app_template_data'];

      if (empty($app_template_data)) {
        return Base::sendError('invalid_template_data', 'The app template data cannot be empty', 400);
      }

      // Add the data to the options table
      $result = update_option($this->app_template_option_key, $app_template_data);

      if(false === $result){
        return Base::sendError('failed', 'Failed to upload the app template', 400);
      }

      return new WP_REST_Response(['success' => true]);
    } catch (\Throwable $th) {
      return Base::sendError('internal_error', $th->getMessage(), 500);
    }
  }
}
