<?php

namespace WooStoreProApi\Api;

defined('ABSPATH') or wp_die('No scripts!');

require_once(__DIR__ . '/base.php');

use WP_REST_Server;
use WooStoreProApi\Api\Base;
use WP_Error;
use WP_REST_Response;

class WooStoreProSettings extends Base
{
  public function __construct()
  {
    $this->namespace = 'woostore_pro_api/settings';
  }

  public function register_routes()
  {

    register_rest_route($this->namespace, '/version', array(
      array(
        'methods'   => WP_REST_Server::READABLE,
        'callback'  => function(){
          return WOOSTORE_PRO_API_VERSION;
        },
        'permission_callback' => function(){
          return true;
        },
      ),
    ));

    register_rest_route($this->namespace, '/activate-license', array(
      array(
        'methods'   => WP_REST_Server::CREATABLE,
        'callback'  => array($this, 'activate_license'),
        'permission_callback' => array($this, 'admin_permissions_check'),
      ),
    ));

    register_rest_route($this->namespace, '/deactivate-license', array(
      array(
        'methods'   => WP_REST_Server::CREATABLE,
        'callback'  => array($this, 'deactivate_license'),
        'permission_callback' => array($this, 'admin_permissions_check'),
      ),
    ));

    register_rest_route($this->namespace, '/update-jwt', array(
      array(
        'methods'   => WP_REST_Server::CREATABLE,
        'callback'  => array($this, 'update_jwt'),
        'permission_callback' => array($this, 'admin_permissions_check'),
      ),
    ));

    register_rest_route($this->namespace, '/update-firebase-server-key', array(
      array(
        'methods'   => WP_REST_Server::CREATABLE,
        'callback'  => array($this, 'update_firebase_server_key'),
        'permission_callback' => array($this, 'admin_permissions_check'),
      ),
    ));

    register_rest_route($this->namespace, '/update-order-notification-title', array(
      array(
        'methods'   => WP_REST_Server::CREATABLE,
        'callback'  => array($this, 'update_order_notification_title'),
        'permission_callback' => array($this, 'admin_permissions_check'),
      ),
    ));

    register_rest_route($this->namespace, '/update-order-notification-message', array(
      array(
        'methods'   => WP_REST_Server::CREATABLE,
        'callback'  => array($this, 'update_order_notification_message'),
        'permission_callback' => array($this, 'admin_permissions_check'),
      ),
    ));
  }

  /**
   * @param \WP_REST_Request $request
   */
  public function activate_license($request){
    try {
      $purchase_code = $request->get_json_params()['purchase_code'];
      update_option("woostore_pro_purchase_code", true);
      update_option("woostore_pro_purchase_code_key", $purchase_code);
      return new WP_REST_Response(['success'=>true]);
    } catch (\Throwable $th) {
      return new WP_Error(400, $th->getMessage());
    }
  }

  /**
   * @param \WP_REST_Request $request
   */
  public function deactivate_license($request)
  {
    try {
      delete_option("woostore_pro_purchase_code");
      delete_option("woostore_pro_purchase_code_key");
      // delete_option('woostore_pro_api_secret_jwt_key');
      delete_option("woostore_pro_firebase_server_key");
      delete_option("woostore_pro_status_order_title");
      delete_option("woostore_pro_status_order_message");
      return new WP_REST_Response(['success' => true]);
    } catch (\Throwable $th) {
      return new WP_Error(400, $th->getMessage());
    }
  }

  /**
   * @param \WP_REST_Request $request
   */
  public function update_jwt($request)
  {
    try {
      $jwt_key = $request->get_json_params()['jwt_key'];
      update_option('woostore_pro_api_secret_jwt_key', $jwt_key);
      return new WP_REST_Response(['success' => true]);
    } catch (\Throwable $th) {
      return new WP_Error('jwt_error', $th->getMessage());
    }
  }
  
  /**
   * @param \WP_REST_Request $request
   */
  public function update_firebase_server_key($request)
  {
    try {
      $firebase_server_key = $request->get_json_params()['firebase_server_key'];
      update_option("woostore_pro_firebase_server_key", $firebase_server_key);
      return new WP_REST_Response(['success' => true]);
    } catch (\Throwable $th) {
      return new WP_Error('firebase_server_key_error', $th->getMessage());
    }
  }

  /**
   * @param \WP_REST_Request $request
   */
  public function update_order_notification_title($request)
  {
    try {
      $title = $request->get_json_params()['title'];
      update_option("woostore_pro_status_order_title", $title);
      return new WP_REST_Response(['success' => true]);
    } catch (\Throwable $th) {
      return new WP_Error('order_status_title_error', $th->getMessage());
    }
  }

  /**
   * @param \WP_REST_Request $request
   */
  public function update_order_notification_message($request)
  {
    try {
      $message = $request->get_json_params()['message'];
      update_option("woostore_pro_status_order_message", $message);
      return new WP_REST_Response(['success' => true]);
    } catch (\Throwable $th) {
      return new WP_Error('order_status_message_error', $th->getMessage());
    }
  }

}
