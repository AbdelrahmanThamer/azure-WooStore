<?php
// Copyright (c) 2022 Aniket Malik [aniketmalikwork@gmail.com] 
// All Rights Reserved.
// 
// NOTICE: All information contained herein is, and remains the
// property of Aniket Malik. The intellectual and technical concepts
// contained herein are proprietary to Aniket Malik and are protected
// by trade secret or copyright law.
// 
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// Aniket Malik.

namespace WooStoreProApi\Api;

defined('ABSPATH') or wp_die('No scripts!');

use AuthUtils;
use Exception;
use Firebase\JWT\ExpiredException;
use WooStoreProApi\Api\Base;
use WOOSTORE_PRO_API\JWT\JWT;
use WP_REST_Server;
use WP_REST_Request;
use WP_REST_Response;

include_once WOOSTORE_PRO_API_PATH . '/includes/cart_utils.php';
include_once WOOSTORE_PRO_API_PATH . '/includes/auth_utils.php';

class WooStoreProCart extends Base
{
  public function register_routes()
  {
    register_rest_route(
      Base::createNameSpace('v2', 'cart'),
      '/guest',
      array(
        array(
          'methods'   => WP_REST_Server::CREATABLE,
          'callback'  => array($this, 'handle_guest_cart'),
          'permission_callback' => function () {
            return parent::checkApiPermission();
          }
        ),
      )
    );

    register_rest_route(
      Base::createNameSpace('v2', 'cart'),
      '/upload_file',
      array(
        array(
          'methods'   => WP_REST_Server::CREATABLE,
          'callback'  => array($this, 'handle_file_upload'),
          'permission_callback' => function () {
            return parent::checkApiPermission();
          }
        ),
      )
    );

    register_rest_route(
      Base::createNameSpace('v2', 'cart'),
      '/checkout',
      array(
        array(
          'methods'   => WP_REST_Server::READABLE,
          'callback'  => array($this, 'checkout'),
          'permission_callback' => function () {
            return parent::checkApiPermission();
          }
        ),
      )
    );

    register_rest_route(
      Base::createNameSpace('v2', 'cart'),
      '/get',
      array(
        array(
          'methods'   => WP_REST_Server::READABLE,
          'callback'  => array($this, 'get_cart'),
          'permission_callback' => function () {
            return parent::checkApiPermission();
          }
        ),
      )
    );

    register_rest_route(
      Base::createNameSpace('v2', 'cart'),
      '/merge',
      array(
        array(
          'methods'   => WP_REST_Server::CREATABLE,
          'callback'  => array($this, 'merge_cart'),
          'permission_callback' => function () {
            return parent::checkApiPermission();
          }
        ),
      )
    );

    register_rest_route(
      Base::createNameSpace('v2', 'cart'),
      '/add-item',
      array(
        array(
          'methods'   => WP_REST_Server::CREATABLE,
          'callback'  => array($this, 'add_to_cart'),
          'permission_callback' => function () {
            return parent::checkApiPermission();
          }
        ),
      )
    );

    register_rest_route(
      Base::createNameSpace('v2', 'cart'),
      '/update-item',
      array(
        array(
          'methods'   => WP_REST_Server::CREATABLE,
          'callback'  => array($this, 'update_item'),
          'permission_callback' => function () {
            return parent::checkApiPermission();
          }
        ),
      )
    );

    register_rest_route(
      Base::createNameSpace('v2', 'cart'),
      '/remove-items',
      array(
        array(
          'methods'   => WP_REST_Server::CREATABLE,
          'callback'  => array($this, 'remove_items'),
          'permission_callback' => function () {
            return parent::checkApiPermission();
          }
        ),
      )
    );

    register_rest_route(
      Base::createNameSpace('v2', 'cart'),
      '/update',
      array(
        array(
          'methods'   => WP_REST_Server::CREATABLE,
          'callback'  => array($this, 'update_cart'),
          'permission_callback' => function () {
            return parent::checkApiPermission();
          }
        ),
      )
    );

    register_rest_route(
      Base::createNameSpace('v2', 'cart'),
      '/clear',
      array(
        array(
          'methods'   => WP_REST_Server::READABLE,
          'callback'  => array($this, 'clear_cart'),
          'permission_callback' => function () {
            return parent::checkApiPermission();
          }
        ),
      )
    );
  }

  /**
   * Start the checkout process of the user
   * @param WP_REST_Request $request
   * @return WP_REST_Response|WP_Error $response
   */
  function checkout($request)
  {
    $params = $request->get_params();
    $jwt = $params['jwt'];
    if (empty($jwt)) {
      return parent::sendError(
        'invalid_token',
        'JWT cannot be empty',
        400
      );
    }

    $secret_key = get_option('woostore_pro_api_secret_jwt_key');

    /** First thing, check the secret key if not exist return a error*/
    if (!$secret_key || empty($secret_key)) {
      return parent::sendError(
        'jwt_auth_bad_config',
        'JWT is not configurated properly, please contact the admin',
        403
      );
    }

    try {
      // This is the data payload
      $d = JWT::decode($jwt, $secret_key, array('HS256'));
      $user_id = $d->data->user->id;

      // after the user_id is available, set the user as current user
      if (empty($user_id)) {
        return parent::sendError('invalid_token', 'Could not find the user', 404);
      }

      $user = get_userdata($user_id);
      wp_set_current_user($user_id, $user->user_login);
      wp_set_auth_cookie($user_id);
      do_action('wp_login', $user->user_login, $user);

      wp_redirect(wc_get_checkout_url());
      exit;
    } catch (\Throwable $th) {

      if ($th instanceof ExpiredException) {
        return parent::sendError(
          'expired_token',
          $th->getMessage() . ' Please login again!',
          403
        );
      }

      return parent::sendError(
        'jwt_auth_bad_config',
        $th->getMessage(),
        403
      );
    }
  }

  /**
   * Get the cart contents for the user
   * @param WP_REST_Request $request
   * @return WP_REST_Response|WP_Error $response
   */
  function get_cart($request)
  {
    try {
      $params = $request->get_params();

      // Validate auth token
      $customer_id = AuthUtils::validateJWT($params['jwt']);
      if (is_wp_error($customer_id)) {
        /** @var WP_Error */
        $e = $customer_id;
        return Base::sendError("jwt_auth_error", $e->get_error_message(), 400);
      }

      $cart = CartUtils::get_customer_cart($customer_id);
      if (is_wp_error($cart)) {
        return Base::sendError('create_cart_error', 'Cannot create cart for user', 400);
      }

      return CartUtils::prepare_cart_for_response($cart);
    } catch (\Throwable $th) {
      return parent::sendError(
        'get_cart_error',
        $th->getMessage(),
        400
      );
    }
  }

  /**
   * Get the cart contents for the user
   * @param WP_REST_Request $request
   * @return WP_REST_Response|WP_Error $response
   */
  function add_to_cart($request)
  {
    try {
      $params = $request->get_params();

      // Validate auth token
      $customer_id = AuthUtils::validateJWT($params['jwt']);
      if (is_wp_error($customer_id)) {
        return $customer_id;
      }

      if ($customer_id === null || $customer_id === 0) {
        return Base::sendError('invalid_customer_id', 'No user found. Please login to add items to cart', 400);
      }

      wp_set_current_user($customer_id);
      wp_set_auth_cookie($customer_id);

      $product_id = $params['product_id'];
      $quantity = $params['quantity'];
      $variation_id = $params['variation_id'];
      $variation_data = isset($params['variation_data']) ? $params['variation_data'] : null;
      $cart_item_data = isset($params['cart_item_data']) ? $params['cart_item_data'] : array();

      return $this->add_to_cart_helper($product_id, $quantity, $variation_id, $variation_data, $cart_item_data);
    } catch (\Throwable $th) {
      return parent::sendError(
        'add_to_cart_error',
        $th->getMessage(),
        400
      );
    }
  }

  /**
   * @param array $params contains infromation about the cart like line_items, coupon, etc.
   * @return \WP_REST_Response|\WP_Error
   */
  public function handle_guest_cart($params)
  {
    try {
      $coupon_code = (string) $params['coupon_code'];
      $line_items = (array) $params['line_items'];

      $line_item_add_to_cart_response = [];
      $cart = WC()->cart;
      $cart->empty_cart();
      foreach ($line_items as $line_item) {
        try {
          $add_to_cart_response = $this->add_to_cart_helper(
            $line_item['product_id'],
            $line_item['quantity'],
            isset($line_item['variation_id']) ? $line_item['variation_id'] : null,
            isset($line_item['variation']) ? $line_item['variation'] : null,
            isset($line_item['cart_item_data']) ? $line_item['cart_item_data'] : null,
          );

          if (is_wp_error($add_to_cart_response)) {
            $line_item_add_to_cart_response[] = array(
              "error" => $add_to_cart_response->get_error_message(),
              "line_item" => array(
                "product_id" => $line_item['product_id'],
                "variation_id" => $line_item['variation_id']
              )
            );
          } else {
            $line_item_add_to_cart_response[] = array(
              "success" => true,
              "response" => $add_to_cart_response['item']['cart_item_key'],
              "line_item" => array(
                "product_id" => $line_item['product_id'],
                "variation_id" => $line_item['variation_id']
              )
            );
          }
        } catch (\Throwable $th) {
          $line_item_add_to_cart_response[] = array(
            "error" => array(
              "code" => $th->getCode(),
              "message" => $th->getMessage(),
            ),
            "line_item" => array(
              "product_id" => $line_item['product_id'],
              "variation_id" => $line_item['variation_id']
            )
          );
        }
      }

      if (!empty($coupon_code)) {
        WC()->cart->apply_coupon($coupon_code);
      }

      return CartUtils::prepare_cart_for_response($cart, array('line_items_add_to_cart_result' => $line_item_add_to_cart_response));
    } catch (\Throwable $th) {
      return Base::sendError('WooStore Pro Api create_cart_with_details', $th->getMessage(), 400);
    }
  }

  /**
   * @param \WP_REST_Request $request The file to be uploaded to the website
   * @return array information about the uploaded file
   */
  function handle_file_upload($request)
  {
    try {
      if (!class_exists('WC_Product_Addons_Helper')) {
        return Base::sendError('missing_plugin', 'WC Products Add on plugin is missing', 400);
      }

      $params = $request->get_params();

      if (isset($params['jwt']) && !empty($params['jwt'])) {

        // Validate auth token
        $customer_id = AuthUtils::validateJWT($params['jwt']);
        if (is_wp_error($customer_id)) {
          return $customer_id;
        }

        if ($customer_id === null || $customer_id === 0) {
          return Base::sendError('invalid_customer_id', 'No user found. Please login to add items to cart', 400);
        }

        wp_set_current_user($customer_id);
        wp_set_auth_cookie($customer_id);
      }

      if (isset($_FILES["file"])) {

        $file = $_FILES["file"];
        // check for file sizes
        $file_size  = $file['size'];
        $allow_upload = \WC_Product_Addons_Helper::can_upload($file_size);
        $max_size = wp_max_upload_size();
        if ($allow_upload === false) {
          return Base::sendError('file_max_size_error', 'The file cannot be more than ' . $max_size, 400);
        }

        $file_upload_result = $this->handle_upload($file);
        return $file_upload_result;
      } else {
        throw new Exception('No file found', 400);
      }
    } catch (\Throwable $th) {
      return Base::sendError('handle_file_upload_error', $th->getMessage(), 500);
    }
  }

  /**
   * @param \WP_REST_Request $request
   * @return \WP_REST_Response|\WP_Error
   */
  public function merge_cart($request)
  {
    try {
      $params = $request->get_params();
      $coupon_code = (string) $params['coupon_code'];
      $line_items = (array) $params['line_items'];

      // Validate auth token
      $customer_id = AuthUtils::validateJWT($params['jwt']);
      if (is_wp_error($customer_id)) {
        /** @var WP_Error */
        $e = $customer_id;
        return Base::sendError("jwt_auth_error", $e->get_error_message(), 400);
      }

      wp_set_current_user($customer_id);
      wp_set_auth_cookie($customer_id);

      $cart = CartUtils::get_customer_cart($customer_id);
      $line_item_add_to_cart_response = [];
      foreach ($line_items as $line_item) {
        try {
          $add_to_cart_response = $this->add_to_cart_helper(
            $line_item['product_id'],
            $line_item['quantity'],
            isset($line_item['variation_id']) ? $line_item['variation_id'] : null,
            isset($line_item['variation']) ? $line_item['variation'] : null,
            isset($line_item['cart_item_data']) ? $line_item['cart_item_data'] : null,
          );

          if (is_wp_error($add_to_cart_response)) {
            $line_item_add_to_cart_response[] = array(
              "error" => $add_to_cart_response->get_error_message(),
              "line_item" => array(
                "product_id" => $line_item['product_id'],
                "variation_id" => $line_item['variation_id']
              )
            );
          } else {
            $line_item_add_to_cart_response[] = array(
              "success" => true,
              "response" => $add_to_cart_response['item']['cart_item_key'],
              "line_item" => array(
                "product_id" => $line_item['product_id'],
                "variation_id" => $line_item['variation_id']
              )
            );
          }
        } catch (\Throwable $th) {
          $line_item_add_to_cart_response[] = array(
            "error" => array(
              "code" => $th->getCode(),
              "message" => $th->getMessage(),
            ),
            "line_item" => array(
              "product_id" => $line_item['product_id'],
              "variation_id" => $line_item['variation_id']
            )
          );
        }
      }

      if (!empty($coupon_code)) {
        WC()->cart->apply_coupon($coupon_code);
      }

      return CartUtils::prepare_cart_for_response($cart, array('line_items_add_to_cart_result' => $line_item_add_to_cart_response));
    } catch (\Throwable $th) {
      return Base::sendError('WooStore Pro Api create_cart_with_details', $th->getMessage(), 400);
    }
  }

  /**
   * Get the cart contents for the user
   * @param WP_REST_Request $request
   * @return WP_REST_Response|WP_Error $response
   */
  function update_item($request)
  {
    try {
      $params = $request->get_params();

      // Validate auth token
      $customer_id = AuthUtils::validateJWT($params['jwt']);
      if (is_wp_error($customer_id)) {
        /** @var WP_Error */
        $e = $customer_id;
        return Base::sendError("jwt_auth_error", $e->get_error_message(), 400);
      }

      $cart = CartUtils::get_customer_cart($customer_id);
      if (is_wp_error($cart)) {
        return Base::sendError('create_cart_error', 'Cannot create cart for user', 400);
      }

      $product_id = $params['product_id'];
      $quantity = $params['quantity'];
      $variation_id = $params['variation_id'];
      $variation_data = isset($params['variation_data']) ? $params['variation_data'] : null;
      $cart_item_data = isset($params['cart_item_data']) ? $params['cart_item_data'] : array();
      return $this->update_item_in_cart_helper($product_id, $quantity, $variation_id, $variation_data, $cart_item_data);
    } catch (\Throwable $th) {
      return parent::sendError(
        'update_item_in_cart_error',
        $th->getMessage(),
        400
      );
    }
  }

  /**
   * Get the cart contents for the user
   * @param WP_REST_Request $request
   * @return WP_REST_Response|WP_Error $response
   */
  public function remove_items($request)
  {
    try {
      $params = $request->get_params();

      // Validate auth token
      $customer_id = AuthUtils::validateJWT($params['jwt']);
      if (is_wp_error($customer_id)) {
        /** @var WP_Error */
        $e = $customer_id;
        return Base::sendError("jwt_auth_error", $e->get_error_message(), 400);
      }

      $cart = CartUtils::get_customer_cart($customer_id);
      if (is_wp_error($cart)) {
        return Base::sendError('create_cart_error', 'Cannot create cart for user', 400);
      }

      // The new line items to be added to the cart
      $cart_item_keys = (array)$params['cart_item_keys'];

      foreach ($cart_item_keys as $cart_item_key) {
        $this->remove_from_cart_helper($cart_item_key);
      }

      return CartUtils::prepare_cart_for_response($cart);
    } catch (\Throwable $th) {
      return parent::sendError(
        'update_cart_error',
        $th->getMessage(),
        400
      );
    }
  }

  /**
   * Get the cart contents for the user
   * @param WP_REST_Request $request
   * @return WP_REST_Response|WP_Error $response
   */
  public function update_cart($request)
  {
    try {
      $params = $request->get_params();

      // Validate auth token
      $customer_id = AuthUtils::validateJWT($params['jwt']);
      if (is_wp_error($customer_id)) {
        /** @var WP_Error */
        $e = $customer_id;
        return Base::sendError("jwt_auth_error", $e->get_error_message(), 400);
      }

      $cart = CartUtils::get_customer_cart($customer_id);
      if (is_wp_error($cart)) {
        return Base::sendError('create_cart_error', 'Cannot create cart for user', 400);
      }

      // The new line items to be added to the cart
      $line_items = (array)$params['line_items'];

      if (!($cart->is_empty())) {
        $cart->empty_cart();
      }

      foreach ($line_items as $key => $line_item) {
        $product_id = $line_item['product_id'];
        $quantity = $line_item['quantity'];
        $variation_id = $line_item['variation_id'];
        $variation_data = isset($line_item['variation_data']) ? $line_item['variation_data'] : null;
        $cart_item_data = isset($line_item['cart_item_data']) ? $line_item['cart_item_data'] : array();
        return $this->add_to_cart_helper($product_id, $quantity, $variation_id, $variation_data, $cart_item_data);
      }

      return CartUtils::prepare_cart_for_response($cart);
    } catch (\Throwable $th) {
      return parent::sendError(
        'update_cart_error',
        $th->getMessage(),
        400
      );
    }
  }

  /**
   * Clear the cart for the customer
   * @param WP_REST_Request $request
   * @return WP_REST_Response|WP_Error $response
   */
  public function clear_cart($request)
  {
    try {
      $params = $request->get_params();

      // Validate auth token
      $customer_id = AuthUtils::validateJWT($params['jwt']);
      if (is_wp_error($customer_id)) {
        /** @var WP_Error */
        $e = $customer_id;
        return Base::sendError("jwt_auth_error", $e->get_error_message(), 400);
      }

      $cart = CartUtils::get_customer_cart($customer_id);
      if (is_wp_error($cart)) {
        return Base::sendError('create_cart_error', 'Cannot create cart for user', 400);
      }

      if (!($cart->is_empty())) {
        $cart->empty_cart(true);
      }

      return new WP_REST_Response(['success' => true]);
    } catch (\Throwable $th) {
      return parent::sendError(
        'clear_cart_error',
        $th->getMessage(),
        400
      );
    }
  }

  /**
   * Add a product to the cart.
   *
   * @param int $product_id contains the id of the product to add to the cart.
   * @param int $quantity contains the quantity of the item to add.
   * @param int $variation_id ID of the variation being added to the cart.
   * @param array $variation attribute values.
   * @param array $cart_item_data extra cart item data we want to pass into the item.
   * @return array|bool|\WP_Error $cart_item 
   * @throws Exception Plugins can throw an exception to prevent adding to cart.
   */
  private function add_to_cart_helper($product_id = 0, $quantity = 1, $variation_id = 0, $variation = array(), $cart_item_data = array())
  {

    try {

      $product_id = absint($product_id);
      $variation_id = absint($variation_id);

      // Ensure we don't add a variation to the cart directly by variation ID.
      if ('product_variation' === get_post_type($product_id)) {
        $variation_id = $product_id;
        $product_id = wp_get_post_parent_id($variation_id);
      }

      $product_data = wc_get_product($variation_id ? $variation_id : $product_id);
      $quantity = apply_filters('woocommerce_add_to_cart_quantity', $quantity, $product_id);

      if ($quantity <= 0) {
        throw new Exception("The quantity must be a valid number greater than 0");
      }
      if (!$product_data) {
        throw new Exception("The product cannot be not found");
      }
      if ('trash' === $product_data->get_status()) {
        throw new Exception("The product is in trash");
      }

      // Load cart item data - may be added by other plugins.
      $cart_item_data = (array)apply_filters('woocommerce_add_cart_item_data', $cart_item_data, $product_id, $variation_id, $quantity);

      // Generate a ID based on product ID, variation ID, variation data, and other cart item data.
      $cart_id = WC()->cart->generate_cart_id($product_id, $variation_id, $variation, $cart_item_data);

      // Find the cart item key in the existing cart.
      $cart_item_key = WC()->cart->find_product_in_cart($cart_id);

      // Force quantity to 1 if sold individually and check for existing item in cart.
      if ($product_data->is_sold_individually()) {
        $quantity = apply_filters('woocommerce_add_to_cart_sold_individually_quantity', 1, $quantity, $product_id, $variation_id, $cart_item_data);
        $found_in_cart = apply_filters('woocommerce_add_to_cart_sold_individually_found_in_cart', $cart_item_key && WC()->cart->cart_contents[$cart_item_key]['quantity'] > 0, $product_id, $variation_id, $cart_item_data, $cart_id);

        if ($found_in_cart) {
          /* translators: %s: product name */
          throw new Exception(sprintf('<a href="%s" class="button wc-forward">%s</a> %s', wc_get_cart_url(), __('View cart', 'woocommerce'), sprintf(__('You cannot add another "%s" to your cart.', 'woocommerce'), $product_data->get_name())));
        }
      }


      if (!$product_data->is_purchasable()) {
        $message = __('Sorry, this product cannot be purchased.', 'woocommerce');
        /**
         * Filters message about product unable to be purchased.
         *
         * @param string $message Message.
         * @param WC_Product $product_data Product data.
         * @since 3.8.0
         */
        $message = apply_filters('woocommerce_cart_product_cannot_be_purchased_message', $message, $product_data);
        throw new Exception($message);
      }



      // Stock check - only check if we're managing stock and backorders are not allowed.
      if (!$product_data->is_in_stock()) {
        /* translators: %s: product name */
        throw new Exception(sprintf(__('You cannot add &quot;%s&quot; to the cart because the product is out of stock.', 'woocommerce'), $product_data->get_name()));
      }

      if (!$product_data->has_enough_stock($quantity)) {
        /* translators: 1: product name 2: quantity in stock */
        throw new Exception(sprintf(__('You cannot add that amount of &quot;%1$s&quot; to the cart because there is not enough stock (%2$s remaining).', 'woocommerce'), $product_data->get_name(), wc_format_stock_quantity_for_display($product_data->get_stock_quantity(), $product_data)));
      }

      // Stock check - this time accounting for whats already in-cart.
      if ($product_data->managing_stock()) {
        $products_qty_in_cart = WC()->cart->get_cart_item_quantities();

        if (isset($products_qty_in_cart[$product_data->get_stock_managed_by_id()]) && !$product_data->has_enough_stock($products_qty_in_cart[$product_data->get_stock_managed_by_id()] + $quantity)) {
          throw new Exception(
            sprintf(
              '<a href="%s" class="button wc-forward">%s</a> %s',
              wc_get_cart_url(),
              __('View cart', 'woocommerce'),
              /* translators: 1: quantity in stock 2: current quantity */
              sprintf(__('You cannot add that amount to the cart &mdash; we have %1$s in stock and you already have %2$s in your cart.', 'woocommerce'), wc_format_stock_quantity_for_display($product_data->get_stock_quantity(), $product_data), wc_format_stock_quantity_for_display($products_qty_in_cart[$product_data->get_stock_managed_by_id()], $product_data))
            )
          );
        }
      }

      // If cart_item_key is set, the item is already in the cart.
      if ($cart_item_key) {
        $new_quantity = $quantity + WC()->cart->cart_contents[$cart_item_key]['quantity'];
        WC()->cart->set_quantity($cart_item_key, $new_quantity, true);
      } else {
        $cart_item_key = $cart_id;

        // Add item after merging with $cart_item_data - hook to allow plugins to modify cart item.
        WC()->cart->cart_contents[$cart_item_key] = apply_filters(
          'woocommerce_add_cart_item',
          array_merge(
            $cart_item_data,
            array(
              'key' => $cart_item_key,
              'product_id' => $product_id,
              'variation_id' => $variation_id,
              'variation' => $variation,
              'quantity' => $quantity,
              'data' => $product_data,
              'data_hash' => wc_get_cart_item_data_hash($product_data),
            )
          ),
          $cart_item_key
        );
      }

      WC()->cart->cart_contents = apply_filters('woocommerce_cart_contents_changed', WC()->cart->cart_contents);
      do_action('woocommerce_add_to_cart', $cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data);
      WC()->cart->check_cart_items();
      WC()->cart->persistent_cart_update();
      if (!headers_sent()) {
        WC()->session->set_customer_session_cookie(true);
      }
      WC()->cart->maybe_set_cart_cookies();
      return array(
        'item' => CartUtils::prepare_single_cart_item_for_response(
          $cart_item_key,
          $product_id,
          $variation_id,
          isset($new_quantity) ? $new_quantity : $quantity,
          $cart_item_data
        ),
        'subtotal' => WC()->cart->get_subtotal(),
      );
    } catch (Exception $e) {
      return parent::sendError(
        'add_to_cart_error',
        html_entity_decode(strip_tags($e->getMessage())),
        400
      );
    }
  }

  /**
   * Update the item in cart helper.
   *
   * @param int $product_id contains the id of the product to add to the cart.
   * @param int $quantity contains the quantity of the item to add.
   * @param int $variation_id ID of the variation being added to the cart.
   * @param array $variation attribute values.
   * @param array $cart_item_data extra cart item data we want to pass into the item.
   * @return string|bool $cart_item_key
   * @throws Exception Plugins can throw an exception to prevent adding to cart.
   */
  private function update_item_in_cart_helper($product_id = 0, $quantity = 1, $variation_id = 0, $variation = array(), $cart_item_data = array())
  {
    try {

      $product_id = absint($product_id);
      $variation_id = absint($variation_id);

      // Ensure we don't add a variation to the cart directly by variation ID.
      if ('product_variation' === get_post_type($product_id)) {
        $variation_id = $product_id;
        $product_id = wp_get_post_parent_id($variation_id);
      }

      $product_data = wc_get_product($variation_id ? $variation_id : $product_id);
      $quantity = apply_filters('woocommerce_add_to_cart_quantity', $quantity, $product_id);

      if ($quantity <= 0) {
        throw new Exception("The quantity must be a valid number greater than 0");
      }
      if (!$product_data) {
        throw new Exception("The product cannot be not found");
      }
      if ('trash' === $product_data->get_status()) {
        throw new Exception("The product is in trash");
      }

      // Load cart item data - may be added by other plugins.
      $cart_item_data = (array)apply_filters('woocommerce_add_cart_item_data', $cart_item_data, $product_id, $variation_id, $quantity);

      // Generate a ID based on product ID, variation ID, variation data, and other cart item data.
      $cart_id = WC()->cart->generate_cart_id($product_id, $variation_id, $variation, $cart_item_data);

      // Find the cart item key in the existing cart.
      $cart_item_key = WC()->cart->find_product_in_cart($cart_id);

      // Force quantity to 1 if sold individually and check for existing item in cart.
      if ($product_data->is_sold_individually()) {
        $quantity = apply_filters('woocommerce_add_to_cart_sold_individually_quantity', 1, $quantity, $product_id, $variation_id, $cart_item_data);
        $found_in_cart = apply_filters('woocommerce_add_to_cart_sold_individually_found_in_cart', $cart_item_key && WC()->cart->cart_contents[$cart_item_key]['quantity'] > 0, $product_id, $variation_id, $cart_item_data, $cart_id);

        if ($found_in_cart) {
          /* translators: %s: product name */
          throw new Exception(sprintf('<a href="%s" class="button wc-forward">%s</a> %s', wc_get_cart_url(), __('View cart', 'woocommerce'), sprintf(__('You cannot add another "%s" to your cart.', 'woocommerce'), $product_data->get_name())));
        }
      }

      if (!$product_data->is_purchasable()) {
        $message = __('Sorry, this product cannot be purchased.', 'woocommerce');
        /**
         * Filters message about product unable to be purchased.
         *
         * @param string $message Message.
         * @param WC_Product $product_data Product data.
         * @since 3.8.0
         */
        $message = apply_filters('woocommerce_cart_product_cannot_be_purchased_message', $message, $product_data);
        throw new Exception($message);
      }

      // Stock check - only check if we're managing stock and backorders are not allowed.
      if (!$product_data->is_in_stock()) {
        /* translators: %s: product name */
        throw new Exception(sprintf(__('You cannot add &quot;%s&quot; to the cart because the product is out of stock.', 'woocommerce'), $product_data->get_name()));
      }

      if (!$product_data->has_enough_stock($quantity)) {
        /* translators: 1: product name 2: quantity in stock */
        throw new Exception(sprintf(__('You cannot add that amount of &quot;%1$s&quot; to the cart because there is not enough stock (%2$s remaining).', 'woocommerce'), $product_data->get_name(), wc_format_stock_quantity_for_display($product_data->get_stock_quantity(), $product_data)));
      }

      // Stock check - this time accounting for whats already in-cart.
      if ($product_data->managing_stock()) {
        $products_qty_in_cart = WC()->cart->get_cart_item_quantities();

        if (isset($products_qty_in_cart[$product_data->get_stock_managed_by_id()]) && !$product_data->has_enough_stock($products_qty_in_cart[$product_data->get_stock_managed_by_id()] + $quantity)) {
          throw new Exception(
            sprintf(
              '<a href="%s" class="button wc-forward">%s</a> %s',
              wc_get_cart_url(),
              __('View cart', 'woocommerce'),
              /* translators: 1: quantity in stock 2: current quantity */
              sprintf(__('You cannot add that amount to the cart &mdash; we have %1$s in stock and you already have %2$s in your cart.', 'woocommerce'), wc_format_stock_quantity_for_display($product_data->get_stock_quantity(), $product_data), wc_format_stock_quantity_for_display($products_qty_in_cart[$product_data->get_stock_managed_by_id()], $product_data))
            )
          );
        }
      }

      // If cart_item_key is set, the item is already in the cart.
      if ($cart_item_key) {
        WC()->cart->set_quantity($cart_item_key, $quantity, true);
      } else {
        $cart_item_key = $cart_id;

        // Add item after merging with $cart_item_data - hook to allow plugins to modify cart item.
        WC()->cart->cart_contents[$cart_item_key] = apply_filters(
          'woocommerce_add_cart_item',
          array_merge(
            $cart_item_data,
            array(
              'key' => $cart_item_key,
              'product_id' => $product_id,
              'variation_id' => $variation_id,
              'variation' => $variation,
              'quantity' => $quantity,
              'data' => $product_data,
              'data_hash' => wc_get_cart_item_data_hash($product_data),
            )
          ),
          $cart_item_key
        );
      }

      WC()->cart->check_cart_items();
      WC()->cart->persistent_cart_update();
      if (!headers_sent()) {
        WC()->session->set_customer_session_cookie(true);
      }
      WC()->cart->maybe_set_cart_cookies();

      WC()->cart->cart_contents = apply_filters('woocommerce_cart_contents_changed', WC()->cart->cart_contents);
      do_action('woocommerce_add_to_cart', $cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data);
      return array(
        'item' =>
        CartUtils::prepare_single_cart_item_for_response(
          $cart_item_key,
          $product_id,
          $variation_id,
          isset($new_quantity) ? $new_quantity : $quantity,
          $cart_item_data
        ),
        'subtotal' => WC()->cart->get_subtotal(),
      );
    } catch (Exception $e) {
      return parent::sendError(
        'update_item_in_cart_error',
        html_entity_decode(strip_tags($e->getMessage())),
        400
      );
    }
  }

  /**
   * Remove an item from the cart.
   *
   * @param int $product_id contains the id of the product to add to the cart.
   * @param int $quantity contains the quantity of the item to add.
   * @param int $variation_id ID of the variation being added to the cart.
   * @param array $variation attribute values.
   * @param array $cart_item_data extra cart item data we want to pass into the item.
   * @return string|bool $cart_item_key
   * @throws Exception Plugins can throw an exception to prevent adding to cart.
   */
  private function remove_from_cart_helper($cart_item_key)
  {
    try {

      if (!empty($cart_item_key)) {
        WC()->cart->remove_cart_item($cart_item_key);
        WC()->cart->check_cart_items();
        WC()->cart->persistent_cart_update();
        if (!headers_sent()) {
          WC()->session->set_customer_session_cookie(true);
        }
        WC()->cart->maybe_set_cart_cookies();
        return true;
      }
      throw new Exception("Please provide a cart item key", 400);
    } catch (Exception $e) {
      return parent::sendError(
        'remove_from_cart_error',
        html_entity_decode(strip_tags($e->getMessage())),
        400
      );
    }
  }

  /**
   * Handle file upload
   * @param  string $file
   * @return array
   */
  function handle_upload($file)
  {
    include_once(ABSPATH . 'wp-admin/includes/file.php');
    include_once(ABSPATH . 'wp-admin/includes/media.php');

    add_filter('upload_dir',  array($this, 'upload_dir'));

    $upload = wp_handle_upload($file, array('test_form' => false));

    remove_filter('upload_dir',  array($this, 'upload_dir'));

    return $upload;
  }

  /**
   * upload_dir function.
   *
   * @access public
   * @param mixed $pathdata
   * @return void
   */
  function upload_dir($pathdata)
  {
    if (empty($pathdata['subdir'])) {
      $pathdata['path']   = $pathdata['path'] . '/woostore_pro_product_addons_uploads/' . md5(WC()->session->get_customer_id());
      $pathdata['url']    = $pathdata['url'] . '/woostore_pro_product_addons_uploads/' . md5(WC()->session->get_customer_id());
      $pathdata['subdir'] = '/woostore_pro_product_addons_uploads/' . md5(WC()->session->get_customer_id());
    } else {
      $subdir             = '/woostore_pro_product_addons_uploads/' . md5(WC()->session->get_customer_id());
      $pathdata['path']   = str_replace($pathdata['subdir'], $subdir, $pathdata['path']);
      $pathdata['url']    = str_replace($pathdata['subdir'], $subdir, $pathdata['url']);
      $pathdata['subdir'] = str_replace($pathdata['subdir'], $subdir, $pathdata['subdir']);
    }

    return apply_filters('woocommerce_product_addons_upload_dir', $pathdata);
  }

  /**
   * @param String $pool_name
   * @return \LWS\WOOREWARDS\Core\Pool|null pool
   */
  private function get_wooreward_pool($pool_name)
  {
    /** @var \LWS\WOOREWARDS\Core\Pool */
    $pool_to_use = null;
    foreach (\LWS\WOOREWARDS\Collections\Pools::instanciate()->load(array('deep' => false))->asArray() as $pool) {
      /** @var \LWS\WOOREWARDS\Core\Pool */
      $pool = $pool;

      // if ($pool->getName() === $pool_name) {
      //   $pool_to_use = $pool;
      // }

      // Hard coded the name of the pool in the api to easier change
      if ($pool->getName() === '1-6') {
        $pool_to_use = $pool;
      }
    }
    return $pool_to_use;
  }
}
