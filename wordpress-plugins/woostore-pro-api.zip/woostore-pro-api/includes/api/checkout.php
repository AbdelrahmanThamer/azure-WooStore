<?php
// Copyright (c) 2021 Aniket Malik [aniketmalikwork@gmail.com] 
// All Rights Reserved.
// 
// NOTICE: All information contained herein is, and remains the
// property of Aniket Malik. The intellectual and technical concepts
// contained herein are proprietary to Aniket Malik and are protected
// by trade secret or copyright law.
// 
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// Aniket Malik.

namespace WooStoreProApi\Api;

defined('ABSPATH') or wp_die('No scripts!');

require_once(__DIR__ . '/base.php');

use AuthUtils;
use Automattic\WooCommerce\Admin\Overrides\Order;
use WOOSTORE_PRO_API\JWT\JWT;
use Firebase\JWT\ExpiredException;
use WC_Coupon;
use WC_Discounts;
use WC_REST_Coupons_Controller;
use WC_Shipping_Rate;
use WP_REST_Server;
use WooStoreProApi\Api\Base;
use WP_REST_Response;
use WP_REST_Request;
use WP_Error;

class WooStoreProCheckoutController extends Base
{

  public function __construct()
  {
    $this->namespace = 'woostore_pro_api/checkout';
  }

  public function register_routes()
  {

    register_rest_route($this->namespace, '/get-shipping-methods', array(
      array(
        'methods'   => WP_REST_Server::CREATABLE,
        'callback'  => array($this, 'get_shipping_methods'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/verify-coupon', array(
      array(
        'methods'   => WP_REST_Server::CREATABLE,
        'callback'  => array($this, 'verify_coupon'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/pay', array(
      array(
        'methods'   => WP_REST_Server::READABLE,
        'callback'  => array($this, 'pay'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route($this->namespace, '/review-details', array(
      array(
        'methods'   => WP_REST_Server::CREATABLE,
        'callback'  => array($this, 'review_details'),
        'permission_callback' => function () {
          return parent::checkApiPermission();
        }
      ),
    ));

    register_rest_route(
      Base::createNameSpace('v2', 'checkout'),
      '/webview',
      array(
        array(
          'methods'   => WP_REST_Server::READABLE,
          'callback'  => array($this, 'webview_checkout'),
          'permission_callback' => function () {
            return parent::checkApiPermission();
          }
        ),
      )
    );
  }

  /**
   * @param WP_REST_Request $request
   * @return WP_REST_Response
   */
  public function get_shipping_methods($request)
  {

    try {

      $params = $request->get_params();

      include_once WOOSTORE_PRO_API_PATH . '/includes/cart_utils.php';
      // Initiate the cart and get the shipping methods
      CartUtils::create_cart_with_details($params);

      $shippng = array();
      // Loop though shipping packages
      foreach (WC()->shipping()->get_packages() as $key => $package) {
        // Loop through Shipping rates
        foreach ($package['rates'] as $rate_id => $rate) {

          /**
           * @var \WC_Shipping_Rate
           */
          $rate = $rate;

          $shippng[] =  array(
            'method_id' => $rate->get_method_id(),
            'instance_id' => (string)$rate->get_instance_id(),
            'method_title' => $rate->get_label(),
            'cost' => $rate->get_cost()
          );
        }
      }

      return new WP_REST_Response($shippng);
    } catch (\Throwable $th) {
      return new WP_Error('get_shipping_error', $th->getMessage());
    }
  }

  /**
   * @param WP_REST_Request $request
   * @return WP_REST_Response
   */
  public function verify_coupon($request)
  {

    // Testing with the order
    try {
      $params = $request->get_params();
      $coupon_code = (string) $params['coupon_code'];
      $line_items = (array) $params['line_items'];
      $customer_id = (int) $params['customer_id'];

      $wc_order = new Order();
      $wc_order->set_id(time());
      $wc_order->set_customer_id($customer_id != null ? $customer_id : 0);

      // Add data to order object
      if (isset($line_items) && is_array($line_items)) {
        foreach ($line_items as $line_item) {
          if (isset($line_item['variation_id']) && $line_item['variation_id'] != 0) {
            // get variation
            $p = wc_get_product($line_item['variation_id']);
          } else {
            // get simple product
            $p = wc_get_product($line_item['product_id']);
          }
          try {
            $wc_order->add_product($p, $line_item['quantity']);
          } catch (\Throwable $th) {
            return new WP_Error($th->getCode(), $th->getMessage());
            break;
          }
        }
      } else {
        return new WP_Error('invalid_cart_items', 'The cart items provided are invalid or empty', array());
      }

      $wc_discounts = new WC_Discounts($wc_order);
      $wc_coupon = new WC_Coupon($coupon_code);

      $result = $wc_discounts->is_coupon_valid($wc_coupon);

      $wc_order->delete();

      if (is_wp_error($result)) {
        return new WP_Error($result->get_error_code(), wp_strip_all_tags($result->get_error_message()), $result->get_error_data());
      }

      $coupon_rest_controller = new WC_REST_Coupons_Controller();

      if (is_bool($result)) {
        if ($result) {
          return new WP_REST_Response([
            'is_coupon_valid' => $result,
            'coupon' => $coupon_rest_controller->prepare_object_for_response($wc_coupon, $request)->data,
          ]);
        } else {
          return new WP_Error(400, 'Coupon is not valid for the items');
        }
      }
    } catch (\Throwable $th) {
      return new WP_Error($th->getCode(), $th->getMessage());
    }
  }

  /**
   * Function for checkout payment.
   */
  public function pay($request)
  {
    $query_params = $request->get_params();
    $jwt = $query_params['jwt'];
    $order_id = $query_params['order_id'];
    $order = wc_get_order($order_id);

    if (is_bool($order) || is_wp_error($order)) {
      return Base::sendError('some_code', $order, 400);
      wp_redirect(WOOSTORE_PRO_API_URL . 'templates/invalid-order.html');
      exit;
    }

    if (empty($jwt)) {
      $url = $order->get_checkout_payment_url();
      wp_redirect($url);
      exit;
    }

    $secret_key = get_option('woostore_pro_api_secret_jwt_key');

    /** First thing, check the secret key if not exist return a error*/
    if (!$secret_key || empty($secret_key)) {
      wp_redirect(WOOSTORE_PRO_API_URL . 'templates/jwt-auth-bad-config.html');
      exit;
    }

    try {
      // This is the data payload
      $d = JWT::decode($jwt, $secret_key, array('HS256'));
      $user_id = $d->data->user->id;

      // after the user_id is available, set the user as current user
      if (empty($user_id)) {
        wp_redirect(WOOSTORE_PRO_API_URL . 'templates/invalid-user-token.html');
        exit;
      }

      wp_set_current_user($user_id);
      wp_set_auth_cookie($user_id);
      $user = wp_get_current_user();
      do_action('wp_login', $user->user_login, $user);
      $url = $order->get_checkout_payment_url();
      wp_redirect($url);
      exit;
    } catch (\Throwable $th) {
      wp_redirect(WOOSTORE_PRO_API_URL . 'templates/jwt-auth-bad-config.html');
      exit;
    }
  }

  /**
   * @param WP_REST_Request $request
   * @return WP_REST_Response
   */
  public function review_details($request)
  {
    try {
      include_once WOOSTORE_PRO_API_PATH . '/includes/cart_utils.php';
      $cart = CartUtils::create_cart_with_details($request->get_params());

      return new WP_REST_Response($cart->get_totals());
    } catch (\Throwable $th) {
      return Base::sendError('WooStore Pro Api review order error', $th->getMessage(), 400);
    }
  }

  /**
   * Start the checkout process of the user
   * @param WP_REST_Request $request
   * @return void
   */
  function webview_checkout($request)
  {
    try {
      $params = $request->get_params();
      $jwt = $params['jwt'];
      $cart_data = isset($params['cart_data']) && is_string($params['cart_data']) ? json_decode($params['cart_data'], true) : null;

      if (empty($jwt) || $jwt === null) {
        // create a wc sesstion
        if (empty($cart_data) || $cart_data === null) {
          return Base::sendError('invalid_params', 'Auth Token and Cart Data cannot both be empty', 400);
        }
        CartUtils::check_prerequisites();
        $cart = CartUtils::create_cart_with_details($cart_data);
        if (is_wp_error($cart)) {
          return $cart;
        }
        wp_redirect(add_query_arg($params, wc_get_checkout_url()));
        exit;
      }

      $user_id = AuthUtils::validateJWT($jwt);
      if (is_wp_error($user_id)) {
        return $user_id;
      }

      // after the user_id is available, set the user as current user
      if (empty($user_id)) {
        return parent::sendError('invalid_token', 'Could not find the user', 404);
      }

      $user = get_userdata($user_id);
      wp_set_current_user($user_id, $user->user_login);
      wp_set_auth_cookie($user_id);
      do_action('wp_login', $user->user_login, $user);
      wp_redirect(add_query_arg($params, wc_get_checkout_url()));
      exit;
    } catch (\Throwable $th) {
      return parent::sendError(
        'webview_checkout_error',
        $th->getMessage(),
        403
      );
    }
  }
}
