<?php
/**
 * Copyright (c) 2021 Aniket Malik [aniketmalikwork@gmail.com] 
 * All Rights Reserved.
 * 
 * NOTICE: All information contained herein is, and remains the
 * property of Aniket Malik. The intellectual and technical concepts
 * contained herein are proprietary to Aniket Malik and are protected
 * by trade secret or copyright law.
 * 
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained from
 * Aniket Malik.
 */

defined('ABSPATH') or wp_die('No scripts!');

include_once WOOSTORE_PRO_API_PATH . '/includes/api/base.php';

use WooStoreProApi\Api\Base;

class WooStoreProAdmin extends Base
{

  public function __construct()
  {
    add_action('admin_menu', [$this, 'create_admin_menu']);
  }

  public function create_admin_menu()
  {
    $hook_suffix = add_menu_page(
      'WooStore Pro Api',
      'WooStore Pro Api',
      'manage_options',
      'woostore-pro-api-plugin',
      [$this, 'menu_page_template']
    );

    add_action("admin_print_scripts-$hook_suffix", array($this, 'load_scripts'));
    add_action("admin_print_styles-$hook_suffix", array($this, 'remove_default_stylesheets'));
  }

  public function menu_page_template()
  {
?>
    <div id="woostore-pro-api-render-stage"></div>
<?php
  }

  public function load_scripts()
  {
    $result = $this->prepare_settings_data();
    wp_enqueue_style(
      'woostore-pro-api-css',
      WOOSTORE_PRO_API_URL . 'assets/css/main.css',
      array(),
      wp_rand()
    );
    wp_enqueue_script('woostore-pro-api-hide', WOOSTORE_PRO_API_URL . 'assets/js/hide.js', [], wp_rand(), true);
    wp_enqueue_script('woostore-pro-api', site_url('wp-content/plugins/woostore-pro-api/bundle.min.js'), ['jquery', 'wp-element'], wp_rand(), true);
    wp_localize_script('woostore-pro-api', 'woostoreProApiSettings', $result);
  }

  public function remove_default_stylesheets()
  {
    wp_deregister_style('wp-admin');
  }
}

// Initiate the admin menu
new WooStoreProAdmin();